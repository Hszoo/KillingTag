-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- show default status bar (iOS)
display.setStatusBar( display.DefaultStatusBar )

-- include Corona's "widget" library
local widget = require "widget"
local composer = require "composer"


local json = require "json"

function jsonParse( src )
	local filename = system.pathForFile( src ) --json파일 읽기
	
	local data, pos, msg
	data, pos, msg = json.decodeFile(filename) --json형식의 데이터를 파싱해서 데이터를 받아줌
	--pos,msg는 몇번째줄에 어떤 오류가 있는지

	-- 디버깅
	if data then --data파싱이 잘되면
		return data
	else --오류가 있으면
		print("WARNING: " .. pos, msg)
		return nil
	end
end

-- event listeners for tab buttons:
local function onFirstView( event )
	composer.gotoScene( "floor4" ) -- 첫번째로 불러올 루아파일 이름
	composer.showOverlay("item")

end


onFirstView()	-- invoke first tab button's onPress event manually
