-----------------------------------------------------------------------------------------
--
-- class4.lua
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()

function scene:create( event )
	local sceneGroup = self.view

    --배경 설정
    local background = display.newImageRect("image/4com.png", display.contentWidth, display.contentHeight)
	background.x, background.y = display.contentWidth/2, display.contentHeight/2
   
    --양 옆 이동 
	local right = display.newImage("image/right.png")
	right.x, right.y = display.contentWidth*0.87, display.contentHeight*0.5
	local left = display.newImage("image/left.png")
	left.x, left.y = display.contentWidth*0.02, display.contentHeight*0.5

  
   --오른쪽키 누르면 floor4으로 장면 이동
    function right:tap( event )
        composer.gotoScene("floor4") -- 추가
		print("floor4으로 이동")
    end
    right:addEventListener("tap", right)
    
    --왼쪽키 누르면 5678로 이동
    local function tapLeft( event )
		composer.gotoScene("5678")
		print("5678으로 이동")
	end
	left:addEventListener("tap", tapLeft)

	
	--문 클릭하면 

	function backgroundTap ( event )
		if((event.x > 50 and event.x < 285 and event.y > 216 and event.y <630)
			or (event.x > 664 and event.x < 770 and event.y > 297 and event.y <520)
			or (event.x > 1030 and event.x < 1093 and event.y > 300 and event.y <585)) then
		--    local success= display.newText("방송실 열쇠 획득", display.contentWidth/2, display.contentHeight/2)
		composer.showOverlay("notice")
		end
	end
	self.view:addEventListener("tap", backgroundTap)


   sceneGroup:insert(background)
   sceneGroup:insert(left)
   sceneGroup:insert(right)
   

end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen
	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.

	end	
end
function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
        composer.removeScene("class4")
	elseif phase == "did" then
		-- Called when the scene is now off screen

	end
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene
