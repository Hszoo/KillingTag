-----------------------------------------------------------------------------------------
--
-- class8.lua (3-8반, 방송실 열쇠 획득 구역)
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()

function scene:create( event )
	local sceneGroup = self.view

    --배경 설정
    local background = display.newImageRect("image/3-8.png", display.contentWidth, display.contentHeight)
	background.x, background.y = display.contentWidth/2, display.contentHeight/2

   
    --왼쪽 이동 키
	local left = display.newImage("image/left.png")
	left.x, left.y = display.contentWidth*0.02, display.contentHeight*0.5

    --문 사진 투명하게 적용이 안됨..
    local opendoor = display.newImage("image/open.jpg")
    opendoor.x, opendoor.y = display.contentWidth*0.1, display.contentHeight*0.37
    opendoor.alpha = 0.5
  

   --왼쪽 키 누르면 밖으로 이동(5678.lua로 이동~)
    function left:tap( event )
        composer.gotoScene("5678") -- 추가
		print("5678으로 이동")
    end
    left:addEventListener("tap", left)
    
    --대화창 띄우기
    composer.showOverlay("chat")

    --책상 클릭하면

    function backgroundTap ( event )
        if(event.x > 250 and event.x < 380 and event.y > 400 and event.y <430) then
            print("방송실 열쇠 획득")

            items[item_index] = display.newImage(itemGroup, "image/mediakey.png")
		    items[item_index].x, items[item_index].y = display.contentWidth*0.945, display.contentHeight*0.1 + (item_index-1)*130
            inventoryGroup:insert(items[item_index])
            item_index = item_index + 1
            inventory_index = inventory_index + 1
            key_index = item_index
            flag = 1
            --열쇠 찾으면 채팅창 이어서 띄우기 
            composer.showOverlay("get")
        end
    end
    self.view:addEventListener("tap", backgroundTap)

   sceneGroup:insert(background)
   sceneGroup:insert(left)
   sceneGroup:insert(opendoor)

end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen
	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.

	end	
end
function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
        composer.removeScene("class8")
	elseif phase == "did" then
		-- Called when the scene is now off screen

	end
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene
