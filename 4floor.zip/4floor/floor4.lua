-----------------------------------------------------------------------------------------
--
-- floor4.lua (계단, 위아래 이동 가능 구역)
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()
local timeAttack
local endingText

function scene:create( event )
	local sceneGroup = self.view
	
	local background = display.newImage("image/stairs.png")
	background.x, background.y = display.contentWidth/2, display.contentHeight/2

	--양 옆 이동 
	local right = display.newImage("image/right.png")
	right.x, right.y = display.contentWidth*0.87, display.contentHeight*0.5

	local left = display.newImage("image/left.png")
	left.x, left.y = display.contentWidth*0.02, display.contentHeight*0.5

	--계단 위 아래 층 이동
	local stairup = display.newImage("image/stairup.png")
	stairup.x, stairup.y = display.contentWidth*0.47, display.contentHeight*0.25

	local stairdown = display.newImage("image/stairdown.png")
	stairdown.x, stairdown.y = display.contentWidth*0.6, display.contentHeight*0.67
	

	-- 왼쪽으로 이동
	local function tapLeft( event )
		composer.gotoScene("class4")
		print("class4으로 이동")
	end
	left:addEventListener("tap", tapLeft)

	--오른쪽으로 이동
	local function tapRight( event )
		composer.gotoScene("toilet")
		print("toilet으로 이동")
	end
	right:addEventListener("tap", tapRight)

	--notice창 코드

	function backgroundTap ( event )
		if((event.x > 40 and event.x < 153 and event.y > 280 and event.y <580)
			or (event.x > 255 and event.x < 400 and event.y > 278 and event.y < 577)) then
			composer.showOverlay("notice")
		end
	end
	self.view:addEventListener("tap", backgroundTap)



	--레이어 정리
	sceneGroup:insert(background)
	sceneGroup:insert(left)
 	sceneGroup:insert(right)
	sceneGroup:insert(stairup)
 	sceneGroup:insert(stairdown)
	

end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen
	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	--will이 실행된 다음에 did가 실행됨
	if event.phase == "will" then 
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
		composer.removeScene("floor4") --다른 신으로 넘어갈 때 floor4가 삭제되게끔 (처음부터 실행 가능)
		--timer.cancel(timeAttack) --타이머 끝내기
	
	elseif phase == "did" then
		-- Called when the scene is now off screen
	end
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene
