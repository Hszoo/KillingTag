-----------------------------------------------------------------------------------------
--
-- lib1.lua
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()

function scene:create( event )
	local sceneGroup = self.view

	local background = display.newImageRect("image/library1.jpg", display.contentWidth, display.contentHeight)
    background.x, background.y = display.contentWidth / 2, display.contentHeight/ 2

    local left = display.newImageRect("image/leftButton.png", display.contentWidth * 0.02, display.contentHeight * 0.08)
    left.x, left.y = 55, display.contentHeight * 0.5

    local right = display.newImageRect("image/rightButton.png", display.contentWidth * 0.02, display.contentHeight * 0.08)
    right.x, right.y = display.contentWidth - 180, display.contentHeight * 0.5
	
	-- 책 선반 오브젝트
	
	
	-- json parsing
	local Data = jsonParse("json/library.json")
	-- CONTENT
	
	local index = 1
	script = display.newText(Data[index].script, 210, 590)
	script.size = 26
	script:toFront()

	function left:tap(event)
		composer.gotoScene("5F.5F_4")
	end

	function next:tap(event)
		display.remove(script.text)
		index = index + 1
		if(index <= #Data) then
			script.text = Data[index].script
		else
			script.text = ""
		end		
	end


	local itemShelf = display.newRect( 425, 300, 75, 320)

	function itemShelf:tap(event)
		composer.gotoScene("library.itemShelf")
	end
	function otherShelves ( event )
		if (event.x >= 100 and event.x <= 340
		and event.y >= 60 and event.y <= 500) then
			composer.gotoScene("library.bookShelf")
		elseif (event.x >= 480 and event.x <= 1080
			and event.y >= 100 and event.y <= 500) then
				composer.gotoScene("library.bookShelf")
		end
	end
	self.view:addEventListener("tap", otherShelves)

	left:addEventListener("tap", left)
	itemShelf:addEventListener("tap", itemShelf)
	next:addEventListener("tap", next)

	sceneGroup:insert(background)
    sceneGroup:insert(left)
	sceneGroup:insert(right)
	sceneGroup:insert(script)

	
	itemShelf:toBack()
end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen
	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
	elseif phase == "did" then
		-- Called when the scene is now off screen
	end
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene