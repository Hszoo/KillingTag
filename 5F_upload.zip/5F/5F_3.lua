-----------------------------------------------------------------------------------------
--
-- 5F_3.lua
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()

function scene:create( event )
	local sceneGroup = self.view
	
    local background = display.newImageRect("image/5F_3.jpg", display.contentWidth, display.contentHeight)
    background.x, background.y = display.contentWidth / 2, display.contentHeight/ 2

    local left = display.newImageRect("image/leftButton.png", display.contentWidth * 0.02, display.contentHeight * 0.08)
    left.x, left.y = 55, display.contentHeight * 0.5

    local right = display.newImageRect("image/rightButton.png", display.contentWidth * 0.02, display.contentHeight * 0.08)
    right.x, right.y = display.contentWidth - 180, display.contentHeight * 0.5
	
	local up = display.newImageRect("image/upButton.png", display.contentWidth * 0.03, display.contentHeight * 0.08)
    up.x, up.y = display.contentCenterX * 0.93, display.contentCenterY * 0.35

    local down = display.newImageRect("image/downButton.png", display.contentWidth * 0.03, display.contentHeight * 0.08)
    down.x, down.y = display.contentWidth * 0.6, display.contentHeight * 0.7
	
	--이벤트추가
	function left:tap(event)
		composer.gotoScene("5F.5F_4")
	end

    function right:tap(event)
		composer.gotoScene("5F.5F_2")
	end

	function up:tap(event)
		composer.gotoScene()
	end
    function down:tap(event)
        composer.gotoScene()
    end

    left:addEventListener("tap", left)
    right:addEventListener("tap", right)
	up:addEventListener("tap", up)
    down:addEventListener("tap", down)

    sceneGroup:insert(background)
    sceneGroup:insert(left)
	sceneGroup:insert(right)
	sceneGroup:insert(up)
	sceneGroup:insert(down)


end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen
	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
	elseif phase == "did" then
		-- Called when the scene is now off screen
	end
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene
