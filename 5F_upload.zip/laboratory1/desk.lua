-----------------------------------------------------------------------------------------
--
-- desk.lua
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()

function scene:create( event )
	local sceneGroup = self.view

	local background = display.newImageRect("image/lab1_desk.jpg", display.contentWidth, display.contentHeight)
    background.x, background.y = display.contentWidth / 2, display.contentHeight/ 2

	local left = display.newImageRect("image/leftButton.png", display.contentWidth * 0.02, display.contentHeight * 0.08)
    left.x, left.y = 55, display.contentHeight * 0.5

    local right = display.newImageRect("image/rightButton.png", display.contentWidth * 0.02, display.contentHeight * 0.08)
    right.x, right.y = display.contentWidth - 180, display.contentHeight * 0.5
	local key = display.newImageRect("image/item_key.png", display.contentWidth * 0.3, display.contentHeight * 0.3)
    key.x, key.y = display.contentWidth * 0.5, display.contentHeight * 0.48

	--local script = display.newText("", 210, 590)

	--이벤트리스너
	function left:tap(event)
		composer.gotoScene("laboratory1.lab1")
	end

	function next:tap(event)
		display.remove(script.text)
	end

	function key:tap(event)
		display.remove(event.target)
		display.remove(inventory[itemCount])

		script.text = "금색의 열쇠를 획득하였습니다."
		script.size = 25
		script:toFront()

		local get = display.newImageRect(inventoryGroup, "image/inventory_get.png", display.contentWidth * 0.1, display.contentHeight * 0.18)
		get.x, get.y = display.contentWidth - 65, display.contentHeight * 0.09 + (itemCount * 135)
		inventory[itemCount] = display.newImageRect(inventoryGroup, "image/inventory_get.png", display.contentWidth * 0.1, display.contentHeight * 0.18)
		inventory[itemCount].x, inventory[itemCount].y = display.contentWidth - 65, display.contentHeight * 0.09 + (itemCount * 135)
		inventory[itemCount].fill = { type="image", filename="image/item_key.png" }
		itemCount = itemCount + 1

		local effect = composer.getVariable("effect")
		effect:removeSelf()
		effect = nil
	end

    left:addEventListener("tap", left)
	key:addEventListener("tap", key)
	next:addEventListener("tap", next)
	
	sceneGroup:insert(background)
    sceneGroup:insert(left)
	sceneGroup:insert(right)
	sceneGroup:insert(key)
	sceneGroup:insert(script)

	script:toFront()
end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen
	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
	elseif phase == "did" then
		-- Called when the scene is now off screen
	end
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene