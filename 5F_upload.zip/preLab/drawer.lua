-----------------------------------------------------------------------------------------
--
-- drawer.lua
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()

function scene:create( event )
	local sceneGroup = self.view

	-- 아이템 오브젝트
	local item = display.newImageRect("image/item_2.png", 780, 355)
	item.x, item.y = 545, 325

	-- 배경
	local background = display.newImageRect("image/drawer2.jpg", display.contentWidth, display.contentHeight)
    background.x, background.y = display.contentWidth / 2, display.contentHeight/ 2
	
	-- 왼
	local left = display.newImageRect("image/leftButton.png", display.contentWidth * 0.02, display.contentHeight * 0.08)
    left.x, left.y = 55, display.contentHeight * 0.5
 
	-- 오
    local right = display.newImageRect("image/rightButton.png", display.contentWidth * 0.02, display.contentHeight * 0.08)
    right.x, right.y = display.contentWidth - 180, display.contentHeight * 0.5
	
	local Data = jsonParse("json/preLab.json")
	-- CONTENT

	local getItem = 0
	local index = 4
	
	script = display.newText( "금색의 열쇠가 사용되었습니다.", 210, 590)
	script.size = 25
	script:toFront()
	
	local getItem = 0
	local count = 6

	function left:tap(event)
		composer.gotoScene("preLab.cabinet")
	end

	function next:tap(event)
		display.remove(script.text)
		if(index <= 6) then
			script.text = Data[index].script
		elseif(getItem == 1 and count <= #Data) then
			script.text = Data[count].script
			count = count + 1
		end
		index = index + 1
	end

	function item:tap(event)
		getItem = 1
		script.text = "쇠 절단기를 획득하였습니다."
		script:toFront()
		display.remove(event.target)
		display.remove(inventory[itemCount])
			
		local get = display.newImageRect(inventoryGroup, "image/inventory_get.png", display.contentWidth * 0.1, display.contentHeight * 0.18)
		get.x, get.y = display.contentWidth - 65, display.contentHeight * 0.09 + (itemCount * 135)
		inventory[itemCount] = display.newImageRect(inventoryGroup, "image/inventory_get.png", display.contentWidth * 0.1, display.contentHeight * 0.18)
		inventory[itemCount].x, inventory[itemCount].y = display.contentWidth - 65, display.contentHeight * 0.09 + (itemCount * 135)
		inventory[itemCount].fill = { type="image", filename="image/item_2.png" }
		itemCount = itemCount + 1
	end

	left:addEventListener("tap", left)
	next:addEventListener("tap", next)
	item:addEventListener("tap", item)

	sceneGroup:insert(background)
	sceneGroup:insert(left)
	sceneGroup:insert(right)
	sceneGroup:insert(item)
	sceneGroup:insert(script)


end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen
	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
	elseif phase == "did" then
		-- Called when the scene is now off screen
	end
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene