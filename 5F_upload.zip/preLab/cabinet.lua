-----------------------------------------------------------------------------------------
--
-- cabinet.lua
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()

function scene:create( event )
	local sceneGroup = self.view

	-- 배경
	local background = display.newImageRect("image/cabinet.jpg", display.contentWidth, display.contentHeight)
    background.x, background.y = display.contentWidth / 2, display.contentHeight/ 2

	-- 왼
	local left = display.newImageRect("image/leftButton.png", display.contentWidth * 0.02, display.contentHeight * 0.08)
    left.x, left.y = 55, display.contentHeight * 0.5

	-- 오
    local right = display.newImageRect("image/rightButton.png", display.contentWidth * 0.02, display.contentHeight * 0.08)
    right.x, right.y = display.contentWidth - 180, display.contentHeight * 0.5
    
	script.text = ""
	script.size = 25

	-- 서랍 오브젝트
	local drawerGroup = display.newGroup()
    local drawer = {}
    for i = 0, 1 do
        drawer[i] = display.newRect(drawerGroup, display.contentCenterX, display.contentCenterY + 45 + (i * 210), 780, 150)
	end

	-- 왼 event
	function left:tap(event)
		composer.gotoScene("preLab.preLab")

	end

	-- 캐비닛-서랍 event
	function drawer1:tap(event)
		composer.gotoScene("preLab.drawer")
	end
	-- 아이템 없는 서랍
	function drawer0:tap(event)
		script.text = "잠겨 있습니다."
		script:toFront()
	end

	left:addEventListener("tap", left)
  	drawer[1]:addEventListener("tap", drawer1)
	drawer[0]:addEventListener("tap", drawer0)

	sceneGroup:insert(background)
    sceneGroup:insert(left)
	sceneGroup:insert(right)
	sceneGroup:insert(drawerGroup)


  	drawerGroup:toBack()
end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen
	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
	elseif phase == "did" then
		-- Called when the scene is now off screen
	end
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene