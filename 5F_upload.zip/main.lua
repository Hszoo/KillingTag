-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- show default status bar (iOS)
display.setStatusBar( display.DefaultStatusBar )

-- include Corona's "widget" library
local widget = require "widget"
local composer = require "composer"
local json = require "json"

-- 아이템인벤토리
inventoryGroup = display.newGroup()
inventory = {}
itemCount = 0
for i = 0, 8 do
	inventory[i] = display.newImageRect(inventoryGroup, "image/inventory.png", display.contentWidth * 0.1, display.contentHeight * 0.18)		
	inventory[i].x, inventory[i].y = display.contentWidth - 65, display.contentHeight * 0.09 + (i * 135)
end

-- 인벤토리 background
local back = display.newImageRect("image/inventory_back.png", display.contentWidth * 0.195, display.contentHeight)
back.x, back.y = display.contentWidth, display.contentHeight * 0.5

-- 대사창
dialog = display.newImageRect("image/dialog.png", display.contentWidth * 0.9 , display.contentHeight * 0.6)
dialog.x, dialog.y = display.contentCenterX * 0.9, display.contentHeight * 1.05
-- 대사창 다음버튼
next = display.newImageRect("image/next.png", display.contentWidth * 0.044 , display.contentHeight * 0.03)
next.x, next.y = display.contentCenterX * 1.66, display.contentHeight * 0.95
-- 대사
script = display.newText("", 210, 590)
script.size = 25

-- 설정버튼
setting = display.newImageRect("image/setting.png", display.contentWidth * 0.025 , display.contentHeight * 0.043)
setting.x, setting.y = display.contentCenterX * 0.08, display.contentHeight * 0.07

--json parsing
function jsonParse( src )
	local filename = system.pathForFile( src )
	
	local data, pos, msg
	data, pos, msg = json.decodeFile(filename)

	-- 디버깅
	if data then
		return data
	else
		print("WARNING: " .. pos, msg)
		return nil
	end
end

-- 스크립트용 index 
function scriptIndex( event )
	index = index + 1
	if(index > #Data) then 
		index = 1
	end
	--return index
	script.text = Data[index].script
end

--인벤토리 창 스크롤 event
function inventoryGroup:touch( event )
	if( event.phase == "began" ) then
		display.getCurrentStage():setFocus( event.target )
			event.target.isFocus = true
			event.target.yStart = event.target.y

	elseif( event.phase == "moved" ) then
		if( event.target.isFocus ) then
			event.target.y = event.target.yStart + event.yDelta
		end
	elseif( event.phase == "ended" or event.phase == "cancelled") then
		display.getCurrentStage():setFocus( nil)
		event.target.isFocus = false

		-- 스크롤 제한
		if(event.target.y > 0) then
			event.target.y = 0
		elseif(event.target.y < -720) then
			event.target.y = -490
		end
	end
end
inventoryGroup:addEventListener("touch", inventoryGroup)
script:toFront()
inventoryGroup:toFront()

-- event listeners for tab buttons:
local function onFirstView( event )
	composer.gotoScene( "5F.5F_1" )
end

onFirstView()	-- invoke first tab button's onPress event manually
