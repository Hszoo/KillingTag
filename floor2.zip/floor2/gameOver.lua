-----------------------------------------------------------------------------------------
--
-- gameOver.lua
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()

function scene:create( event )
	local sceneGroup = self.view
	
 	local background = display.newImageRect("image/gameOver.png", display.contentWidth, display.contentHeight)
	background.x, background.y = display.contentWidth/2, display.contentHeight/2

	local retry = display.newImage("image/retry.png")
	retry.x, retry.y = display.contentWidth*0.4, display.contentHeight*0.85

	--합치면서 구현 필요
	-- local function tapRetry( event )
	-- 	composer.gotoScene("")
	-- end
	-- retry:addEventListener("tap", tapRetry)

	local home = display.newImage("image/home2.png")
	home.x, home.y = display.contentWidth*0.6, display.contentHeight*0.85

	--합치면서 구현 필요
	-- local function tapHome( event )
	-- 	composer.gotoScene("")
	-- end
	-- home:addEventListener("tap", tapHome)

	-- 모두 sceneGroup에 넣었는지 점검
	sceneGroup:insert(background)
	sceneGroup:insert(retry)
	sceneGroup:insert(home)
end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen

	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
	elseif phase == "did" then
		-- Called when the scene is now off screen

	end
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene