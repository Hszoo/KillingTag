-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- json parsing
local json = require "json" --json libray require하기

function jsonParse( src ) --전역 함수. 매개변수는 파일 경로.
	local filename = system.pathForFile( src ) --json 파일을 읽음
	-- json 형식의 데이터를 파싱해서 data에 받아놓음. json 파일 형식에 오류가 있을 때, 몇번째 줄에 어떤 오류가 있는지 pos와 msg에 정보를 받아옴.
	local data, pos, msg = json.decodeFile(filename)

	-- 디버깅
	if data then --데이터 파싱 성공
		return data
	else --데이터 파싱 실패
		print("WARNING: " .. pos, msg)
		return nil
	end
end

-- show default status bar (iOS)
display.setStatusBar( display.DefaultStatusBar )

-- include Corona's "widget" library
local widget = require "widget"
local composer = require "composer"


-- event listeners for tab buttons:
local function onFirstView( event )
	composer.gotoScene( "floor2" )
end


onFirstView()	-- invoke first tab button's onPress event manually
