-----------------------------------------------------------------------------------------
--
-- studio.lua
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()
local background
local index = 1
local first = 1 --첫 화면
local wire_flag = 0
local mike_flag = 0
local button_flag = 0

local wire_outline = {}
local leftButton, rightButton, backButton
local text, dialog_text

local itemList = {}
local inventory = {} local inventory_red = {}
local item_name = {} local item = {} local itemIntro_text = {}
local content = display.newGroup()

local ItemList = jsonParse("json/itemList.json")
local Data = jsonParse("json/studio_background.json")
-- 아이템 클릭 이벤트 함수 -------------------------------------------------------------------------------------------
local function itemClick( event )
	if itemList ~= nil then
		for i = 1, #itemList do
			if inventory_red[i].alpha == 1 then
				inventory_red[i].alpha = 0
				itemIntro_text[i].alpha = 0
			end
		end

		for i = 1, #itemList do
			if event.target.y + 30 > inventory_red[i].y and event.target.y - 30 < inventory_red[i].y then
				text.alpha = 0
				dialogText.alpha = 0

				inventory_red[i].alpha = 1
				itemIntro_text[i].alpha = 1
				dialog.alpha = 1
 				dialogButton.alpha = 1
			end
		end
	end
end
-- 아이템 획득 함수 -------------------------------------------------------------------------------------------
local function item_get()
	if itemList ~= nil then
		for i = 1, #itemList do
			inventory[i] = display.newImage(content, "image/inventory.png")
			inventory[i].x, inventory[i].y = display.contentWidth*0.947, display.contentHeight*0.09 + (i - 1)*130

			inventory_red[i] = display.newImage(content, "image/inventory_red.png")
			inventory_red[i].x, inventory_red[i].y = display.contentWidth*0.947, display.contentHeight*0.09 + (i - 1)*130
			inventory_red[i].alpha = 0

			item_name[i] = ItemList[itemList[i]].name

			item[i] = display.newImage(content, ItemList[itemList[i]].image)
			item[i].x, item[i].y = display.contentWidth*0.947, display.contentHeight*0.09 + (i - 1)*130

			itemIntro_text[i] = display.newText(0, display.contentWidth*0.5, display.contentHeight*0.88)
			itemIntro_text[i].size = 25
			itemIntro_text[i]:setFillColor(1)
			itemIntro_text[i].text = ItemList[itemList[i]].intro
			itemIntro_text[i].alpha = 0
		end
	end

	if itemList ~= nil then
		for i = 1, #itemList do
			item[i]:addEventListener("tap", itemClick)
		end
	end
end
-- 아이템 추가 함수 -------------------------------------------------------------------------------------------
local function item_plus()
	local i = #itemList
	inventory[i] = display.newImage(content, "image/inventory.png")
	inventory[i].x, inventory[i].y = display.contentWidth*0.947, display.contentHeight*0.09 + (i - 1)*130

	inventory_red[i] = display.newImage(content, "image/inventory_red.png")
	inventory_red[i].x, inventory_red[i].y = display.contentWidth*0.947, display.contentHeight*0.09 + (i - 1)*130
	inventory_red[i].alpha = 0

	item_name[i] = ItemList[itemList[i]].name

	item[i] = display.newImage(content, ItemList[itemList[i]].image)
	item[i].x, item[i].y = display.contentWidth*0.947, display.contentHeight*0.09 + (i - 1)*130

	itemIntro_text[i] = display.newText(0, display.contentWidth*0.5, display.contentHeight*0.88)
	itemIntro_text[i].size = 25
	itemIntro_text[i]:setFillColor(1)
	itemIntro_text[i].text = ItemList[itemList[i]].intro
	itemIntro_text[i].alpha = 0

	item[i]:addEventListener("tap", itemClick)
end
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function scene:create( event )
	local sceneGroup = self.view

	background = display.newImageRect("image/studio1.jpg", display.contentWidth, display.contentHeight)
	background.x, background.y = display.contentWidth/2, display.contentHeight/2

	-- 아이템 리스트 드래그 이벤트 함수 -------------------------------------------------------------------------------------------
	function touchItemList( event )
		if( event.phase == "began" ) then
			display.getCurrentStage():setFocus( event.target )
			event.target.isFocus = true
			event.target.yStart = event.target.y
	
		elseif( event.phase == "moved" ) then
			if( event.target.isFocus ) then
				event.target.y = event.target.yStart + event.yDelta
			end

		elseif( event.phase == "ended" or event.phase == "cancelled") then
			display.getCurrentStage():setFocus(nil)
			event.target.isFocus = false
		end
	end
	--content:addEventListener("touch", touchItemList)

	itemList = composer.getVariable("keyItem")
	item_get()

	dialog = display.newImage("image/dialog.png")
	dialog.x , dialog.y = display.contentWidth*0.5, display.contentHeight*0.9
	dialog.alpha = 0

	dialogButton = display.newImage("image/dialog_next.png")
	dialogButton.x , dialogButton.y = display.contentWidth*0.86, display.contentHeight*0.95
	dialog.alpha = 0

	local function tapDialogButton( event )
		dialog.alpha = 0
		dialogButton.alpha = 0
		text.alpha = 0
		dialog_text.alpha = 0
		if itemList ~= nil then
			for i = 1, #itemList do
				inventory_red[i].alpha = 0
				itemIntro_text[i].alpha = 0
			end
		end
	end
	dialogButton:addEventListener("tap", tapDialogButton)

	text = display.newText(0, display.contentWidth*0.5, display.contentHeight*0.88)
	text.size = 25
	text:setFillColor(1)
	text.alpha = 0

	dialog_text = display.newText(0, display.contentWidth*0.5, display.contentHeight*0.88)
	dialog_text.size = 25
	dialog_text:setFillColor(1)
	dialog_text.alpha = 0

	local studio_mike = display.newRect(display.contentCenterX + 30, display.contentCenterY + 100, 100, 120) -- 그림상 마이크 위치
	-- 마이크 드래그 이벤트 함수 -------------------------------------------------------------------------------------------
	local function dragMike( event )
		if mike_flag == 0 then
	 		if( event.phase == "began" ) then
	 			display.getCurrentStage():setFocus( event.target )
	 			event.target.isFocus = true

	 			event.target.initX = event.target.x
	 			event.target.initY = event.target.y

	 			--content:removeEventListener("touch", touchItemList)

	 		elseif( event.phase == "moved" ) then
	 			if ( event.target.isFocus ) then
	 				event.target.x = event.xStart + event.xDelta - event.target.parent.x
	 				event.target.y = event.yStart + event.yDelta - event.target.parent.y
	 			end

	 		elseif ( event.phase == "ended" or event.phase == "cancelled") then 
	 			if ( event.target.isFocus ) then
		 			display.getCurrentStage():setFocus( nil )
		 			event.target.isFocus = false

		 			if ( event.target.x > studio_mike.x - 50 and event.target.x < studio_mike.x + 50
		 				and event.target.y > studio_mike.y - 50 and event.target.y < studio_mike.y + 50 and index == 1 ) then
		 			 	index = 6
		 			 	background.fill = {
		 					type = "image",
		 					filename = Data[index].image
		 				}

		 				mike_flag = 1

		 				for i = 1, #itemList do
		 					inventory_red[i].alpha = 0
							itemIntro_text[i].alpha = 0
						end
						dialog_text.alpha = 0

		 				text.text = "[고장난 마이크로 변경되었습니다. 이제 방송이 나오지 않습니다.]"
		 				dialog.alpha = 1
		 				dialogButton.alpha = 1
		 				text.alpha = 1

		 				if itemList ~= nil then
							for i = 1, #itemList do
								if item_name[i] == "고장난 마이크" then
								  	item[i].alpha = 0
								end
							end
						end

		 				index = 7
						background.fill = {
							type = "image",
							filename = Data[index].image
						}
					else
		 				event.target.x = event.target.initX
		 				event.target.y = event.target.initY
		 			end
		 		else
		 			display.getCurrentStage():setFocus( nil )
	 				event.target.isFocus = false
	 			end
	 			--content:addEventListener("touch", touchItemList)
	 		end
	 	end
 	end
	if itemList ~= nil then
		for i = 1, #itemList do
			if item_name[i] == "고장난 마이크" then
			  	item[i]:addEventListener("touch", dragMike)
			end
		end
	end

	local wire = display.newRect(display.contentCenterX - 190, display.contentCenterY + 135, 40, 100)
	-- wire 클릭 시 장면 전환 이벤트 함수 -------------------------------------------------------------------------------------------
	local function tapWire( event )
		leftButton.alpha = 0
		rightButton.alpha = 0
		backButton.alpha = 1

		if wire_flag == 0 then -- wire 안 자름
			text.alpha = 0
			if itemList ~= nil then
				for i = 1, #itemList do
					inventory_red[i].alpha = 0
					itemIntro_text[i].alpha = 0
				end
			end

			if itemList ~= nil then
				for i = 1, #itemList do
					if item_name[i] == "가위" then
						dialog_text.text = "일단 모든 경우의 수를 제거해야 해... 미친 살인마한테서 살아남으려면.\n저기 있는 선... 가위로 잘라버리자."
						dialog.alpha = 1
						dialogButton.alpha = 1
						dialog_text.alpha = 1
					end
				end
			end

			index = 3
		elseif wire_flag == 1 then -- wire 자름
			index = 4
		end

	 	background.fill = {
	 		type = "image",
	 		filename = Data[index].image
	 	}
	end
	wire:addEventListener("tap", tapWire)

	local wire_outline_group = display.newGroup() -- wire 선 outline
	wire_outline[1] = display.newRect(wire_outline_group, display.contentCenterX - 370, display.contentCenterY + 110, 70, 100)
	wire_outline[1]:rotate(110)
	wire_outline[2] = display.newRect(wire_outline_group, display.contentCenterX - 300, display.contentCenterY + 170, 70, 100)
	wire_outline[2]:rotate(150)
	wire_outline[3] = display.newRect(wire_outline_group, display.contentCenterX - 247, display.contentCenterY + 250, 70, 100)
	wire_outline[3]:rotate(140)
	wire_outline[4] = display.newRect(wire_outline_group, display.contentCenterX - 160, display.contentCenterY + 275, 70, 100)
	wire_outline[4]:rotate(80)
	wire_outline[5] = display.newRect(wire_outline_group, display.contentCenterX - 65, display.contentCenterY + 250, 70, 100)
	wire_outline[5]:rotate(70)
	wire_outline[6] = display.newRect(wire_outline_group, display.contentCenterX + 30, display.contentCenterY + 220, 70, 100)
	wire_outline[6]:rotate(80)
	wire_outline[7] = display.newRect(wire_outline_group, display.contentCenterX + 125, display.contentCenterY + 235, 70, 100)
	wire_outline[7]:rotate(100)
	wire_outline[8] = display.newRect(wire_outline_group, display.contentCenterX + 220, display.contentCenterY + 260, 70, 100)
	wire_outline[8]:rotate(90)
	wire_outline[9] = display.newRect(wire_outline_group, display.contentCenterX + 315, display.contentCenterY + 240, 70, 100)
	wire_outline[9]:rotate(70)
	wire_outline[10] = display.newRect(wire_outline_group, display.contentCenterX + 390, display.contentCenterY + 180, 70, 100)
	wire_outline[10]:rotate(30)
	wire_outline[11] = display.newRect(wire_outline_group, display.contentCenterX + 420, display.contentCenterY + 90, 70, 100)
	wire_outline[11]:rotate(10)
	wire_outline[12] = display.newRect(wire_outline_group, display.contentCenterX + 430, display.contentCenterY - 10, 70, 100)
	wire_outline[13] = display.newRect(wire_outline_group, display.contentCenterX + 430, display.contentCenterY - 90, 70, 70)

	local controller = display.newRect(display.contentCenterX + 330, display.contentCenterY + 38, 110, 60)
	-- controller 클릭 시 장면 전환 이벤트 함수 -------------------------------------------------------------------------------------------
	local function tapController( event )
		leftButton.alpha = 0
		rightButton.alpha = 0
		backButton.alpha = 1
		control_button.alpha = 1

		index = 5
		background.fill = {
			type = "image",
			filename = Data[index].image
		}

		if button_flag == 0 then -- 버튼 설정 안 함
			text.alpha = 0
			if itemList ~= nil then
				for i = 1, #itemList do
					inventory_red[i].alpha = 0
					itemIntro_text[i].alpha = 0
				end
			end

			dialog_text.text = "볼륨.. 이것만 위로 올라가 있네...?"
			dialog.alpha = 1
			dialogButton.alpha = 1
			dialog_text.alpha = 1
		end
	end
	controller:addEventListener("tap", tapController)

	control_button = display.newImage("image/control_button.png")
	control_button.x, control_button.y = display.contentWidth*0.765, display.contentHeight*0.23
	control_button.alpha = 0
	-- button 드래그 이벤트 함수 -------------------------------------------------------------------------------------------
	local function dragButton( event )
 		if( event.phase == "began" ) then
 			display.getCurrentStage():setFocus( event.target )
 			event.target.isFocus = true

 			event.target.initY = event.target.y
 		elseif( event.phase == "moved" ) then
 			if ( event.target.isFocus ) then
 				if event.yStart + event.yDelta > event.target.initY and event.yStart + event.yDelta < event.target.initY + 110 and button_flag == 0 then
 					event.target.y = event.yStart + event.yDelta - event.target.parent.y
 				end
 			end

 		elseif ( event.phase == "ended" or event.phase == "cancelled") then
 			if ( event.target.isFocus ) then
	 			display.getCurrentStage():setFocus( nil )
	 			event.target.isFocus = false

	 			if event.target.y > event.target.initY + 100 and event.target.y < event.target.initY + 110 then
	 				control_button.y = event.target.y
	 				dialog_text.alpha = 0
	 				if itemList ~= nil then
						for i = 1, #itemList do
							inventory_red[i].alpha = 0
							itemIntro_text[i].alpha = 0
						end
					end

	 				text.text = "[볼륨이 내려갔습니다.]"
	 				text.alpha = 1
	 				dialog.alpha = 1
	 				dialogButton.alpha = 1

	 				button_flag = 1
	 			else
	 				event.target.y = event.target.initY
	 			end
	 		else
	 			display.getCurrentStage():setFocus( nil )
 				event.target.isFocus = false
 			end
 		end
 	end
 	control_button:addEventListener("touch", dragButton)

	leftButton = display.newImage("image/left.png")
	leftButton.x, leftButton.y = display.contentWidth*0.04, display.contentHeight*0.5

	rightButton = display.newImage("image/right.png")
	rightButton.x, rightButton.y = display.contentWidth*0.86, display.contentHeight*0.5

	-- 왼쪽, 오른쪽 방향키 작동 이벤트 함수 -------------------------------------------------------------------------------------------
	local function tapLeftButton( event )
		if index == 1 or index == 6 or index == 7 then
			backButton.alpha = 0

			index = 2
			background.fill = {
				type = "image",
				filename = Data[index].image
			}
		end
	end
	local function tapRightButton( event )
		if index == 2 then
			backButton.alpha = 1

			if mike_flag == 1 then
				index = 7
			else
				index = 1
			end
			background.fill = {
				type = "image",
				filename = Data[index].image
			}
		end
	end
	leftButton:addEventListener("tap", tapLeftButton)
	rightButton:addEventListener("tap", tapRightButton)

	backButton = display.newImage("image/back.png")
	backButton.x, backButton.y = display.contentWidth*0.5, display.contentHeight*0.94
	-- back 방향키 작동 이벤트 함수 -------------------------------------------------------------------------------------------
	local function tapBackButton( event )
		dialog.alpha = 0
		dialogButton.alpha = 0
		dialog_text.alpha = 0
		text.alpha = 0
		if itemList ~= nil then
			for i = 1, #itemList do
				itemIntro_text[i].alpha = 0
				inventory_red[i].alpha = 0
			end
		end

		if index == 3 or index == 4 then
			backButton.alpha = 0
			index = 2
		elseif index == 5 then
			backButton.alpha = 0
			control_button.alpha = 0
			index = 2
		elseif index == 1 or index == 6 or index == 7 then
			composer.gotoScene("floor2")
		end

		background.fill = {
			type = "image",
			filename = Data[index].image
		}

		leftButton.alpha = 1
		rightButton.alpha = 1
	end
	backButton:addEventListener("tap", tapBackButton)

	local setting = display.newImage("image/setting.png")
	setting.x, setting.y = display.contentWidth*0.04, display.contentHeight*0.07

	local function tapSetting( event )
		for i = 1, #itemList do
			inventory_red[i].alpha = 0
			itemIntro_text[i].alpha = 0
		end
		dialog.alpha = 0
		dialogButton.alpha = 0
		text.alpha = 0
		dialog_text.alpha = 0

		composer.showOverlay("setting")
	end
	setting:addEventListener("tap", tapSetting)

	local inventoryList = display.newImage("image/inventory_list.png")
	inventoryList.x, inventoryList.y = display.contentWidth*0.95, display.contentHeight*0.5

	sceneGroup:insert(background)
	sceneGroup:insert(studio_mike)
	sceneGroup:insert(wire)
	sceneGroup:insert(wire_outline_group)
	sceneGroup:insert(controller)
	sceneGroup:insert(control_button)
	sceneGroup:insert(leftButton)
	sceneGroup:insert(rightButton)
	sceneGroup:insert(backButton)
	sceneGroup:insert(setting)
	sceneGroup:insert(dialog)
	sceneGroup:insert(dialogButton)
	sceneGroup:insert(inventoryList)
	sceneGroup:insert(content)

	studio_mike:toBack()
	wire:toBack()
	wire_outline_group:toBack()
	controller:toBack()
end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen
		if first == 1 then
			first = 0
		else
			itemList = composer.getVariable("keyItem")
			item_get()
		end

		-- 가위 드래그 이벤트 함수 -------------------------------------------------------------------------------------------
		local function dragScissors( event )		
	 		if( event.phase == "began" ) then
	 			display.getCurrentStage():setFocus( event.target )
	 			event.target.isFocus = true

	 			event.target.initX = event.target.x
	 			event.target.initY = event.target.y

		 		--content:removeEventListener("touch", touchItemList)

	 		elseif( event.phase == "moved" ) then
	 			if ( event.target.isFocus ) then
	 				event.target.x = event.xStart + event.xDelta - event.target.parent.x
	 				event.target.y = event.yStart + event.yDelta - event.target.parent.y
	 			end

	 		elseif ( event.phase == "ended" or event.phase == "cancelled") then
	 			if ( event.target.isFocus ) then
		 			display.getCurrentStage():setFocus( nil )
		 			event.target.isFocus = false

		 			for i = 1, 13 do
		 				if event.target.x > wire_outline[i].x - 50 and event.target.x < wire_outline[i].x + 50
		 					and event.target.y > wire_outline[i].y - 50 and event.target.y < wire_outline[i].y + 50 and index == 3 then
						 	dialog.alpha = 0
						 	dialogButton.alpha = 0
						 	dialog_text.alpha = 0
						 	if itemList ~= nil then
								for i = 1, #itemList do
									inventory_red[i].alpha = 0
									itemIntro_text[i].alpha = 0
								end
							end

		 			 		background.fill = {
								type = "image",
								filename = Data[4].image
							}
							text.text = "[방송 배선을 잘랐습니다.]"
		 					dialog.alpha = 1
		 					dialogButton.alpha = 1
		 					text.alpha = 1

		 					wire_flag = 1 --자르기 성공
						end
					end
		 			event.target.x = event.target.initX
		 			event.target.y = event.target.initY
		 		else
		 			display.getCurrentStage():setFocus( nil )
	 				event.target.isFocus = false
	 			end
	 			--content:addEventListener("touch", touchItemList)
	 		end
 		end
		if itemList ~= nil then
			for i = 1, #itemList do
				if item_name[i] == "가위" then
				  	item[i]:addEventListener("touch", dragScissors)
				end
			end
		end

	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)

		if mike_flag == 1 and button_flag == 1 then
			composer.setVariable("studio_flag", 1)
		else
			composer.setVariable("studio_flag", 0)
		end

	elseif phase == "did" then
		-- Called when the scene is now off screen
	end
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene
