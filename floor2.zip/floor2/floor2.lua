-----------------------------------------------------------------------------------------
--
-- floor2.lua
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()
local index = 1
local flag = 0
local studio_flag = 0 -- studio에서 트리거 제거 실패
local artRoom_flag = 0 --artRoom 안 들어감
local heal_flag = 1 --heal 가능한 상태

local dialog, dialogButton, text, dialogText

-- local time

local itemList = {}
local inventory = {} local inventory_red = {}
local item_name = {} local item = {} local itemIntro_text = {}
local content = display.newGroup()

local ItemList = jsonParse("json/itemList.json")
-- 아이템 클릭 이벤트 함수 -------------------------------------------------------------------------------------------
local function itemClick( event )
	if itemList ~= nil then
		for i = 1, #itemList do
			if inventory_red[i].alpha == 1 then
				inventory_red[i].alpha = 0
				itemIntro_text[i].alpha = 0
			end
		end

		for i = 1, #itemList do
			if event.target.y + 30 > inventory_red[i].y and event.target.y - 30 < inventory_red[i].y then
				text.alpha = 0
				dialogText.alpha = 0

				inventory_red[i].alpha = 1
				itemIntro_text[i].alpha = 1
				dialog.alpha = 1
 				dialogButton.alpha = 1
			end
		end
	end
end
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function scene:create( event )
	local sceneGroup = self.view
	
	local background = display.newImageRect("image/floor2_1.jpg", display.contentWidth, display.contentHeight)
	background.x, background.y = display.contentWidth/2, display.contentHeight/2

	local Data = jsonParse("json/background.json")

	 -- 타이머 ------------------------------------------------------------------------------------------- 주석
	 -- time = display.newText(60, display.contentWidth*0.13, display.contentHeight*0.1)
	 -- time.size = 20
	 -- time:setFillColor(1)

	 -- local function counter ( event )
	 -- 	time.text = time.text - 1

  -- 		if time.text == '0' then
  -- 			-- killer_run 비디오 추가
	 -- 		dialog.alpha = 0
	 -- 		dialogButton.alpha = 0
	 -- 		text.alpha = 0
	 -- 		dialogText.alpha = 0
	 -- 		if itemList ~= nil then
	 -- 			for i = 1, #itemList do
	 -- 				inventory_red[i].alpha = 0
  -- 			 		itemIntro_text[i].alpha = 0
  -- 			 	end
  -- 			end

  -- 			if itemList ~= nil and heal_flag == 1 then
	 -- 			for i = 1, #itemList do
	 -- 				if item_name[i] == "붕대" then
	 -- 				  	-- killer_run 비디오 추가
	 -- 		 			heal_flag = 0
	 -- 		 			composer.showOverlay("heal_question")
		-- 	 		else
	 -- 		 			composer.gotoScene("gameOver")
	 -- 				end
	 -- 			end
	 -- 		end
  -- 		end

  -- 		if time.text == '5' and studio_flag == 0  then
  -- 			dialogText.alpha = 0
  -- 			if itemList ~= nil then
	 -- 			for i = 1, #itemList do
	 -- 				inventory_red[i].alpha = 0
  -- 			 		itemIntro_text[i].alpha = 0
  -- 			 	end
  -- 			end

  -- 			text.text = "[종료되었습니다.]"
  -- 			dialog.alpha = 1
  -- 			dialogButton.alpha = 1
  -- 			text.alpha = 1
  -- 			-- 살인마 속도, 발걸음 소리 1.5배 음악 다운로드 후 추가
  -- 		end
  -- 	end
  -- 	local timeAttack = timer.performWithDelay(60000, counter, 10)

	-- 아이템 획득 함수 -------------------------------------------------------------------------------------------
	local function item_get()
		if itemList ~= nil then
			for i = 1, #itemList do
				inventory[i] = display.newImage(content, "image/inventory.png")
				inventory[i].x, inventory[i].y = display.contentWidth*0.947, display.contentHeight*0.09 + (i - 1)*130

				inventory_red[i] = display.newImage(content, "image/inventory_red.png")
				inventory_red[i].x, inventory_red[i].y = display.contentWidth*0.947, display.contentHeight*0.09 + (i - 1)*130
				inventory_red[i].alpha = 0

				item_name[i] = ItemList[itemList[i]].name

				item[i] = display.newImage(content, ItemList[itemList[i]].image)
				item[i].x, item[i].y = display.contentWidth*0.947, display.contentHeight*0.09 + (i - 1)*130

				itemIntro_text[i] = display.newText(0, display.contentWidth*0.5, display.contentHeight*0.88)
				itemIntro_text[i].size = 25
				itemIntro_text[i]:setFillColor(1)
				itemIntro_text[i].text = ItemList[itemList[i]].intro
				itemIntro_text[i].alpha = 0
			end
		end

		if itemList ~= nil then
			for i = 1, #itemList do
				item[i]:addEventListener("tap", itemClick)
			end
		end
	end
	-- 아이템 리스트 드래그 이벤트 함수 -------------------------------------------------------------------------------------------
	function touchItemList( event )
		if( event.phase == "began" ) then
			display.getCurrentStage():setFocus( event.target )
			event.target.isFocus = true
			event.target.yStart = event.target.y
	
		elseif( event.phase == "moved" ) then
			if( event.target.isFocus ) then
				event.target.y = event.target.yStart + event.yDelta
			end

		elseif( event.phase == "ended" or event.phase == "cancelled") then
			display.getCurrentStage():setFocus(nil)
			event.target.isFocus = false
		end
	end
	--content:addEventListener("touch", touchItemList)

	-- itemList[#itemList + 1] = 2
	-- itemList[#itemList + 1] = 4
	-- item_get()

	composer.setVariable("keyItem", itemList) -- 다른 scene에 itemList 전달

	--scene1
	local close_door_group = display.newGroup()
	local close_door = {} --문 위치
	close_door[1] = display.newRect(close_door_group, display.contentCenterX + 193, display.contentCenterY + 25, 10, 200)
	close_door[2] = display.newRect(close_door_group, display.contentCenterX + 156, display.contentCenterY + 34, 15, 225)
	close_door[3] = display.newRect(close_door_group, display.contentCenterX + 130, display.contentCenterY + 38, 16, 245)
	close_door[4] = display.newRect(close_door_group, display.contentCenterX + 53, display.contentCenterY + 47, 30, 305)
	close_door[5] = display.newRect(close_door_group, display.contentCenterX, display.contentCenterY + 58, 25, 350)
	close_door[6] = display.newRect(close_door_group, display.contentCenterX - 135, display.contentCenterY + 77, 51, 450)
	--scene2
	close_door[7] = display.newRect(close_door_group, display.contentCenterX + 201, display.contentCenterY + 31, 100, 293)
	close_door[8] = display.newRect(close_door_group, display.contentCenterX + 339, display.contentCenterY + 33, 110, 320)
	close_door[9] = display.newRect(close_door_group, display.contentCenterX - 489, display.contentCenterY + 39, 120, 233)
	--scene3
	close_door[10] = display.newRect(close_door_group, display.contentCenterX - 552, display.contentCenterY + 70, 150, 310)
	close_door[11] = display.newRect(close_door_group, display.contentCenterX - 307, display.contentCenterY + 70, 155, 310)
	--scene4
	close_door[12] = display.newRect(close_door_group, display.contentCenterX + 75, display.contentCenterY + 45, 105, 210)
	close_door[13] = display.newRect(close_door_group, display.contentCenterX - 467, display.contentCenterY + 60, 245, 352)
	--scene5
	close_door[14] = display.newRect(close_door_group, display.contentCenterX + 290, display.contentCenterY + 93, 135, 535)
	close_door[15] = display.newRect(close_door_group, display.contentCenterX + 139, display.contentCenterY + 83, 50, 440)
	close_door[16] = display.newRect(close_door_group, display.contentCenterX + 5, display.contentCenterY + 60, 25, 350)
	close_door[17] = display.newRect(close_door_group, display.contentCenterX - 50, display.contentCenterY + 55, 27, 310)
	close_door[18] = display.newRect(close_door_group, display.contentCenterX - 125, display.contentCenterY + 35, 17, 250)
	close_door[19] = display.newRect(close_door_group, display.contentCenterX - 151, display.contentCenterY + 33, 15, 230)
	close_door[20] = display.newRect(close_door_group, display.contentCenterX - 187, display.contentCenterY + 25, 13, 202)

	local studio_close_door = display.newRect(display.contentCenterX + 45, display.contentCenterY + 33, 107, 270) --studio 문 위치
	local dialogButton_flag = 0 --0: 다음 대화 없음
	-- studio 문 잠김 이벤트 힘수 -------------------------------------------------------------------------------------------
	local function tapStudioCloseDoor( event )
		dialogText.alpha = 0
		if itemList ~= nil then
			for i = 1, #itemList do
				inventory_red[i].alpha = 0
 				itemIntro_text[i].alpha = 0
 			end
 		end

		if index == 2 then
			dialogButton_flag = 1
			text.text = "[문이 잠겨있습니다. 3학년 8반으로 가십시오.]"

			dialog.alpha = 1
			dialogButton.alpha = 1
			text.alpha = 1
		end
	end
	studio_close_door:addEventListener("tap", tapStudioCloseDoor)

	local function tapCloseDoor( event )
		if flag == 0 then
			dialogText.alpha = 0
			for i = 1, #itemList do
				inventory_red[i].alpha = 0
				itemIntro_text[i].alpha = 0
			end

			text.text = "[문이 잠겨있습니다.]"

			dialog.alpha = 1
			dialogButton.alpha = 1
			text.alpha = 1
		end
	end

	-- 문 잠김 이벤트 함수 설정하는 함수 -------------------------------------------------------------------------------------------
	local function closeDoorEvent()
		if index == 1 then
			for i = 1, 6 do
				close_door[i]:addEventListener("tap", tapCloseDoor)
			end
			for i = 7, 20 do
				close_door[i]:removeEventListener("tap", tapCloseDoor)
			end
		elseif index == 2 then
			for i = 7, 9 do
				close_door[i]:addEventListener("tap", tapCloseDoor)
			end
			for i = 1, 6 do
				close_door[i]:removeEventListener("tap", tapCloseDoor)
			end
			for i = 10, 20 do
				close_door[i]:removeEventListener("tap", tapCloseDoor)
			end
		elseif index == 3 then
			for i = 10, 11 do
				close_door[i]:addEventListener("tap", tapCloseDoor)
			end
			for i = 1, 9 do
				close_door[i]:removeEventListener("tap", tapCloseDoor)
			end
			for i = 12, 20 do
				close_door[i]:removeEventListener("tap", tapCloseDoor)
			end
		elseif index == 4 then
			for i = 12, 13 do
				close_door[i]:addEventListener("tap", tapCloseDoor)
			end
			for i = 1, 11 do
				close_door[i]:removeEventListener("tap", tapCloseDoor)
			end
			for i = 14, 20 do
				close_door[i]:removeEventListener("tap", tapCloseDoor)
			end
		elseif index == 5 then
			for i = 14, 20 do
				close_door[i]:addEventListener("tap", tapCloseDoor)
			end
			for i = 1, 13 do
				close_door[i]:removeEventListener("tap", tapCloseDoor)
			end
		end
	end
	closeDoorEvent()

	local studio_door = display.newRect(display.contentCenterX + 45, display.contentCenterY + 35, 100, 250)
	-- studio 열쇠 드래그 이벤트 함수 -------------------------------------------------------------------------------------------
	local function dragStudioKey( event )
 		if( event.phase == "began" ) then  
 			display.getCurrentStage():setFocus( event.target )
 			event.target.isFocus = true

 			for i = 1, #itemList do
 				inventory_red[i].alpha = 0
				itemIntro_text[i].alpha = 0
			end
			dialog.alpha = 0
			dialogButton.alpha = 0
			text.alpha = 0
			dialogText.alpha = 0

 			event.target.initX = event.target.x
 			event.target.initY = event.target.y

 			--content:removeEventListener("touch", touchItemList)

 		elseif( event.phase == "moved" ) then
 			if ( event.target.isFocus ) then
 				event.target.x = event.xStart + event.xDelta - event.target.parent.x
 				event.target.y = event.yStart + event.yDelta - event.target.parent.y
 			end

 		elseif ( event.phase == "ended" or event.phase == "cancelled") then
 			if ( event.target.isFocus ) then 
	 			display.getCurrentStage():setFocus( nil )
	 			event.target.isFocus = false 

	 			if( event.target.x > studio_door.x - 100 and event.target.x < studio_door.x + 100
	 				and event.target.y > studio_door.y - 100 and event.target.y < studio_door.y + 100 and index == 2 ) then
	 				composer.gotoScene("studio")
	 			end

	 			event.target.x = event.target.initX
	 			event.target.y = event.target.initY
	 		else 
	 			display.getCurrentStage():setFocus( nil )
 				event.target.isFocus = false
 			end

 			--content:addEventListener("touch", touchItemList)
 		end
 	end
	if itemList ~= nil then
		for i = 1, #itemList do
			if item_name[i] == "방송실 열쇠" then
			  	item[i]:addEventListener("touch", dragStudioKey)
			end
		end
	end

	local artRoom_door = display.newRect(display.contentCenterX + 453, display.contentCenterY + 70, 120, 270)
	-- artRoom 탭 이벤트 함수 -------------------------------------------------------------------------------------------
	local function tapArtRoomDoor( event )
		if index == 4 and flag == 0 then
			for i = 1, #itemList do
				inventory_red[i].alpha = 0
				itemIntro_text[i].alpha = 0
			end
			dialog.alpha = 0
			dialogButton.alpha = 0
			text.alpha = 0
			dialogText.alpha = 0

			--time.text = time.text - 5

			artRoom_flag = 1
			composer.gotoScene("artRoom")
		end
	end
	artRoom_door:addEventListener("tap", tapArtRoomDoor)

	local leftButton = display.newImage("image/left.png")
	leftButton.x, leftButton.y = display.contentWidth*0.04, display.contentHeight*0.5

	local rightButton = display.newImage("image/right.png")
	rightButton.x, rightButton.y = display.contentWidth*0.86, display.contentHeight*0.5

	local upButton = display.newImage("image/up.png")
	upButton.x, upButton.y = display.contentWidth*0.45, display.contentHeight*0.2
	upButton.alpha = 0

	local downButton = display.newImage("image/down.png")
	downButton.x, downButton.y = display.contentWidth*0.6, display.contentHeight*0.7
	downButton.alpha = 0

	-- 왼쪽, 오른쪽 방향키 작동 이벤트 함수 -------------------------------------------------------------------------------------------
	local function tapLeftButton( event )
		if index < 5 then
			index = index + 1
		end
		background.fill = {
			type = "image",
			filename = Data[index].image
		}

		if index == 3 then
			upButton.alpha = 1
			downButton.alpha = 1
		else
			upButton.alpha = 0
			downButton.alpha = 0
		end

		-- 인형키링이 있을 때 --------------------------------
		if index == 4 and itemList ~= nil then
			for i = 1, #itemList do
				if item_name[i] == "인형키링" then
					text.alpha = 0
					for i = 1, #itemList do
						if inventory_red[i].alpha == 1 then
							inventory_red[i].alpha = 0
							itemIntro_text[i].alpha = 0
						end
					end

					text.text = "[술래잡기를 시작합니다.]"
					dialog.alpha = 1
					dialogButton.alpha = 1
					text.alpha = 1

					-- local time2 = display.newText(15, display.contentWidth*0.23, display.contentHeight*0.1) --아래도 동일
					-- time2.size = 20
					-- time2:setFillColor(1)

					-- local function counter2 ( event )
					-- 	time2.text = time2.text - 1

	 			-- 		if time2.text == '0' then
					--  		if itemList ~= nil and heal_flag == 1 then
					--  			for i = 1, #itemList do
					--  				if item_name[i] == "붕대" then
					--  				  	-- killer_run 비디오 추가
					--  		 			heal_flag = 0
					--  		 			composer.showOverlay("heal_question")
					-- 		 		else
					--  		 			composer.gotoScene("gameOver")
					--  				end
					--  			end
					--  		end
					--  	end
				 -- 	end
				 -- 	timeAttack2 = timer.performWithDelay(1000, counter2, 15)
				end
			end
		end

		closeDoorEvent()

		if index == 3 or index == 4 then
			flag = 1
		end
		timer.performWithDelay( 500, function()
	 			    			flag = 0
	 							end )
	end
	local function tapRightButton( event )
		if index > 1 then
			index = index - 1
		end
		background.fill = {
			type = "image",
			filename = Data[index].image
		}

		if index == 3 then
			upButton.alpha = 1
			downButton.alpha = 1
		else
			upButton.alpha = 0
			downButton.alpha = 0
		end

		-- 인형키링이 있을 때 --------------------------------
		if index == 4 and itemList ~= nil then
			for i = 1, #itemList do
				if item_name[i] == "인형키링" then
					text.alpha = 0
					for i = 1, #itemList do
						if inventory_red[i].alpha == 1 then
							inventory_red[i].alpha = 0
							itemIntro_text[i].alpha = 0
						end
					end

					text.text = "[술래잡기를 시작합니다.]"
					dialog.alpha = 1
					dialogButton.alpha = 1
					text.alpha = 1
				end
			end
		end

		closeDoorEvent()

		if index == 4 then
			flag = 1
		end
		timer.performWithDelay( 500, function()
	 			    			flag = 0
	 							end )
	end
	leftButton:addEventListener("tap", tapLeftButton)
	rightButton:addEventListener("tap", tapRightButton)

	local setting = display.newImage("image/setting.png")
	setting.x, setting.y = display.contentWidth*0.04, display.contentHeight*0.07

	local function tapSetting( event )
		for i = 1, #itemList do
			inventory_red[i].alpha = 0
			itemIntro_text[i].alpha = 0
		end
		dialog.alpha = 0
		dialogButton.alpha = 0
		text.alpha = 0
		dialogText.alpha = 0

		composer.showOverlay("setting")
	end
	setting:addEventListener("tap", tapSetting)

	dialog = display.newImage("image/dialog.png")
	dialog.x , dialog.y = display.contentWidth*0.5, display.contentHeight*0.9
	dialog.alpha = 0

	dialogButton = display.newImage("image/dialog_next.png")
	dialogButton.x , dialogButton.y = display.contentWidth*0.86, display.contentHeight*0.95
	dialogButton.alpha = 0

	local function tapDialogButton( event )
		text.alpha = 0
		if itemList ~= nil then
			for i = 1, #itemList do
				inventory_red[i].alpha = 0
 				itemIntro_text[i].alpha = 0
 			end
 		end

		if dialogButton_flag == 1 then
			dialogText.text = "문이 잠겨있어.. 열쇠를 찾고 와야겠네."
			dialogText.alpha = 1

			dialogButton_flag = 0
		else
			dialog.alpha = 0
			dialogButton.alpha = 0
			dialogText.alpha = 0
		end
	end
	dialogButton:addEventListener("tap", tapDialogButton)

	text = display.newText(0, display.contentWidth*0.5, display.contentHeight*0.88)
	text.size = 25
	text:setFillColor(1)
	text.alpha = 0

	dialogText = display.newText(0, display.contentWidth*0.5, display.contentHeight*0.88)
	dialogText.size = 25
	dialogText:setFillColor(1)
	dialogText.alpha = 0

	local inventoryList = display.newImage("image/inventory_list.png")
	inventoryList.x, inventoryList.y = display.contentWidth*0.95, display.contentHeight*0.5

	sceneGroup:insert(background)
	--sceneGroup:insert(time)
	sceneGroup:insert(close_door_group)
	sceneGroup:insert(studio_close_door)
	sceneGroup:insert(studio_door)
	sceneGroup:insert(artRoom_door)
	sceneGroup:insert(leftButton)
	sceneGroup:insert(rightButton)
	sceneGroup:insert(upButton)
	sceneGroup:insert(downButton)
	sceneGroup:insert(setting)
	sceneGroup:insert(dialog)
	sceneGroup:insert(dialogButton)
	sceneGroup:insert(text)
	sceneGroup:insert(dialogText)
	sceneGroup:insert(inventoryList)
	sceneGroup:insert(content)

	close_door_group:toBack()
	studio_close_door:toBack()
	studio_door:toBack()
	artRoom_door:toBack()
	--time:toBack()
end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen

		-- 아이템 추가 함수 -------------------------------------------------------------------------------------------
		local function item_plus()
			local i = #itemList
			inventory[i] = display.newImage(content, "image/inventory.png")
			inventory[i].x, inventory[i].y = display.contentWidth*0.947, display.contentHeight*0.09 + (i - 1)*130

			inventory_red[i] = display.newImage(content, "image/inventory_red.png")
			inventory_red[i].x, inventory_red[i].y = display.contentWidth*0.947, display.contentHeight*0.09 + (i - 1)*130
			inventory_red[i].alpha = 0

			item_name[i] = ItemList[itemList[i]].name

			item[i] = display.newImage(content, ItemList[itemList[i]].image)
			item[i].x, item[i].y = display.contentWidth*0.947, display.contentHeight*0.09 + (i - 1)*130

			itemIntro_text[i] = display.newText(0, display.contentWidth*0.5, display.contentHeight*0.88)
			itemIntro_text[i].size = 25
			itemIntro_text[i]:setFillColor(1)
			itemIntro_text[i].text = ItemList[itemList[i]].intro
			itemIntro_text[i].alpha = 0

			item[i]:addEventListener("tap", itemClick)
		end

		--------------------------------------------------------------------------------------------------------------	
		studio_flag = composer.getVariable("studio_flag") -- timer에서 쓰임

		local stay = composer.getVariable("stay") -- 미술실 y / n 대답
		if stay == "no" and artRoom_flag == 1 then
			dialog.alpha = 1
		 	dialogButton.alpha = 1
			text.text = "후우... 무슨 교실 하나 들어왔다고 시간이 주냐고... 미친 주최자! 아오!"
			text.alpha = 1

			artRoom_flag = 0
		end

		local timeDecrease = composer.getVariable("timeDecrease") -- 미술실에서 5분 경과 여부
		if timeDecrease == "true" then
			--time.text = time.text / 2
		end
		
		-- artRoom에서 가위 획득 -------------------------------------------------------------------------------------------
		local artRoomItem = composer.getVariable("artRoomItem")

		if artRoomItem ~= nil then
		 	itemList[#itemList] = artRoomItem
		 	item_plus()
		end

	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
	elseif phase == "did" then
		-- Called when the scene is now off screen
	end
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene
