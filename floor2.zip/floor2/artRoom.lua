-----------------------------------------------------------------------------------------
--
-- artRoom.lua
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()
local index = 1
local first = 1 --첫 화면
local flag = 0
local flag_scissors = 0

local dialog, dialogButton, text, dialog_text
local backButton

local time,timeAttack

local itemList = {}
local inventory = {} local inventory_red = {}
local item_name = {} local item = {} local itemIntro_text = {}
local content = display.newGroup()

local ItemList = jsonParse("json/itemList.json")
-- 아이템 클릭 이벤트 함수 -------------------------------------------------------------------------------------------
local function itemClick( event )
	if itemList ~= nil then
		for i = 1, #itemList do
			if inventory_red[i].alpha == 1 then
				inventory_red[i].alpha = 0
				itemIntro_text[i].alpha = 0
			end
		end

		for i = 1, #itemList do
			if event.target.y + 30 > inventory_red[i].y and event.target.y - 30 < inventory_red[i].y then
				text.alpha = 0
				dialog_text.alpha = 0

				inventory_red[i].alpha = 1
				itemIntro_text[i].alpha = 1
				dialog.alpha = 1
 				dialogButton.alpha = 1
			end
		end
	end
end
-- 아이템 획득 함수 -------------------------------------------------------------------------------------------
local function item_get()
	if itemList ~= nil then
		for i = 1, #itemList do
			inventory[i] = display.newImage(content, "image/inventory.png")
			inventory[i].x, inventory[i].y = display.contentWidth*0.947, display.contentHeight*0.09 + (i - 1)*130

			inventory_red[i] = display.newImage(content, "image/inventory_red.png")
			inventory_red[i].x, inventory_red[i].y = display.contentWidth*0.947, display.contentHeight*0.09 + (i - 1)*130
			inventory_red[i].alpha = 0

			item_name[i] = ItemList[itemList[i]].name

			item[i] = display.newImage(content, ItemList[itemList[i]].image)
			item[i].x, item[i].y = display.contentWidth*0.947, display.contentHeight*0.09 + (i - 1)*130

			itemIntro_text[i] = display.newText(0, display.contentWidth*0.5, display.contentHeight*0.88)
			itemIntro_text[i].size = 25
			itemIntro_text[i]:setFillColor(1)
			itemIntro_text[i].text = ItemList[itemList[i]].intro
			itemIntro_text[i].alpha = 0
		end
	end

	if itemList ~= nil then
		for i = 1, #itemList do
			item[i]:addEventListener("tap", itemClick)
		end
	end
end
-- 아이템 추가 함수 -------------------------------------------------------------------------------------------
local function item_plus()
	local i = #itemList
	inventory[i] = display.newImage(content, "image/inventory.png")
	inventory[i].x, inventory[i].y = display.contentWidth*0.947, display.contentHeight*0.09 + (i - 1)*130

	inventory_red[i] = display.newImage(content, "image/inventory_red.png")
	inventory_red[i].x, inventory_red[i].y = display.contentWidth*0.947, display.contentHeight*0.09 + (i - 1)*130
	inventory_red[i].alpha = 0

	item_name[i] = ItemList[itemList[i]].name

	item[i] = display.newImage(content, ItemList[itemList[i]].image)
	item[i].x, item[i].y = display.contentWidth*0.947, display.contentHeight*0.09 + (i - 1)*130

	itemIntro_text[i] = display.newText(0, display.contentWidth*0.5, display.contentHeight*0.88)
	itemIntro_text[i].size = 25
	itemIntro_text[i]:setFillColor(1)
	itemIntro_text[i].text = ItemList[itemList[i]].intro
	itemIntro_text[i].alpha = 0

	item[i]:addEventListener("tap", itemClick)
end
----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
function scene:create( event )
	local sceneGroup = self.view

	local background = display.newImageRect("image/artRoom1.jpg", display.contentWidth, display.contentHeight)
	background.x, background.y = display.contentWidth/2, display.contentHeight/2

	local Data = jsonParse("json/artRoom_background.json")
	-- 아이템 리스트 드래그 이벤트 함수 -------------------------------------------------------------------------------------------
	function touchItemList( event )
		if( event.phase == "began" ) then
			display.getCurrentStage():setFocus( event.target )
			event.target.isFocus = true
			event.target.yStart = event.target.y
	
		elseif( event.phase == "moved" ) then
			if( event.target.isFocus ) then
				event.target.y = event.target.yStart + event.yDelta
			end

		elseif( event.phase == "ended" or event.phase == "cancelled") then
			display.getCurrentStage():setFocus(nil)
			event.target.isFocus = false
		end
	end
	--content:addEventListener("touch", touchItemList) --보완 필요
	
	itemList = composer.getVariable("keyItem")
	item_get()

	local desk = display.newRect(display.contentCenterX - 155, display.contentCenterY + 150, 90, 60)
	-- 가위 획득 여부에 따른 책상 클릭 이벤트 함수 -------------------------------------------------------------------------------------------
	local function tapDesk( event )
		if flag == 0 then
			if flag_scissors == 0 then --가위 획득 안 함
				text.alpha = 0
				for i = 1, #itemList do
					inventory_red[i].alpha = 0
					itemIntro_text[i].alpha = 0
				end

				dialog_text.text = "가위? 이거면 위협은 되겠다. 가져가자."
				dialog.alpha = 1
				dialogButton.alpha = 1
				dialog_text.alpha = 1

				index = 3
			elseif flag_scissors == 1 then
				index = 4
			end

			background.fill = {
				type = "image",
				filename = Data[index].image
			}

			if index == 3 then
				flag = 1
			end
			timer.performWithDelay( 500, function()
									flag = 0
		 							end )
		end
	end
	desk:addEventListener("tap", tapDesk)

	local scissors = display.newRect(display.contentCenterX - 180, display.contentCenterY - 20, 430, 335)
	-- 가위 클릭 시 장면 전환 이벤트 함수 -------------------------------------------------------------------------------------------
	local function tapScissors( event )
		if flag == 0 then
			dialog_text.alpha = 0
			for i = 1, #itemList do
				inventory_red[i].alpha = 0
				itemIntro_text[i].alpha = 0
			end

			if flag_scissors == 0 then --가위 획득 안함
				itemList[#itemList + 1] = 5 --아이템 목록에 가위 추가
				item_plus()

				composer.setVariable("artRoomItem", 5)
			end

			flag_scissors = 1
			index = 4
			background.fill = {
				type = "image",
				filename = Data[index].image
			}

			dialog.alpha = 1
			dialogButton.alpha = 1
			text.text = "[가위를 획득하였습니다.]"
			text.alpha = 1
		end
	end
	scissors:addEventListener("tap", tapScissors)

	backButton = display.newImage("image/back.png")
	backButton.x, backButton.y = display.contentWidth*0.5, display.contentHeight*0.94

	local function tapBackButton( event )
		if index == 3 then
			index = 1
		elseif index == 4 then
			index = 2
		elseif index == 1 or index == 2 then
			dialog.alpha = 0
			dialogButton.alpha = 0
			text.alpha = 0
			dialog_text.alpha = 0
			if itemList ~= nil then
				for i = 1, #itemList do
					itemIntro_text[i].alpha = 0
					inventory_red[i].alpha = 0
				end
			end

			timer.cancel(timeAttack)
			time.alpha = 0

			composer.gotoScene("floor2")
		end

		background.fill = {
			type = "image",
			filename = Data[index].image
		}
	end
	backButton:addEventListener("tap", tapBackButton)

	local setting = display.newImage("image/setting.png")
	setting.x, setting.y = display.contentWidth*0.04, display.contentHeight*0.07

	local function tapSetting( event )
		for i = 1, #itemList do
			inventory_red[i].alpha = 0
			itemIntro_text[i].alpha = 0
		end
		dialog.alpha = 0
		dialogButton.alpha = 0
		text.alpha = 0
		dialog_text.alpha = 0

		composer.showOverlay("setting")
	end
	setting:addEventListener("tap", tapSetting)

	dialog = display.newImage("image/dialog.png")
	dialog.x , dialog.y = display.contentWidth*0.5, display.contentHeight*0.9
	dialog.alpha = 0

	dialogButton = display.newImage("image/dialog_next.png")
	dialogButton.x , dialogButton.y = display.contentWidth*0.86, display.contentHeight*0.95
	dialogButton.alpha = 0

	local function tapDialogButton( event )
		flag = 0
		if itemList ~= nil then
			for i = 1, #itemList do
				item[i]:addEventListener("tap", itemClick)
			end
		end

		dialog.alpha = 0
		dialogButton.alpha = 0
		text.alpha = 0
		dialog_text.alpha = 0
		if itemList ~= nil then
			for i = 1, #itemList do
				inventory_red[i].alpha = 0
				itemIntro_text[i].alpha = 0
			end
		end

		backButton.alpha = 1
	end
	dialogButton:addEventListener("tap", tapDialogButton)

	text = display.newText(0, display.contentWidth*0.5, display.contentHeight*0.88)
	text.size = 25
	text:setFillColor(1)
	text.alpha = 0

	dialog_text = display.newText(0, display.contentWidth*0.5, display.contentHeight*0.88)
	dialog_text.size = 25
	dialog_text:setFillColor(1)
	dialog_text.alpha = 0

	local inventoryList = display.newImage("image/inventory_list.png")
	inventoryList.x, inventoryList.y = display.contentWidth*0.95, display.contentHeight*0.5

	sceneGroup:insert(background)
	sceneGroup:insert(desk)
	sceneGroup:insert(scissors)
	sceneGroup:insert(backButton)
	sceneGroup:insert(setting)
	sceneGroup:insert(dialog)
	sceneGroup:insert(dialogButton)
	sceneGroup:insert(inventoryList)
	sceneGroup:insert(content)

	desk:toBack()
	scissors:toBack()
end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen
		if first == 1 then
			first = 0
		else
			itemList = composer.getVariable("keyItem")
			item_get()
		end

		local stay_y = display.newRect(display.contentCenterX + 180, display.contentCenterY + 273, 30, 30)
		local stay_n = display.newRect(display.contentCenterX + 237, display.contentCenterY + 273, 60, 30)
		-- 미술실 계속 있을지에 대한 이벤트 함수 -------------------------------------------------------------------------------------------
		local function tap_stayState( event )
			text.alpha = 0

			if event.target.x > stay_y.x - 10 and event.target.x < stay_y.x + 10 then --yes
				dialog_text.text = "줄어봐야 고작 5분 정도 줄었겠지. 일단 뭐라도 찾아야 돼. 싸워서라도 이겨야하니까...\n미술실에는 무슨 도구라도 있겠지."
		 		dialog.alpha = 1
		 		dialogButton.alpha = 1
		 		dialog_text.alpha = 1

		 		composer.setVariable("stay", "yes")
			elseif event.target.x > stay_n.x - 10 and event.target.x < stay_n.x + 10 then --no
				dialog.alpha = 0
				dialogButton.alpha = 0
				dialog_text.alpha = 0

				timer.cancel(timeAttack)
				composer.setVariable("stay", "no")

				composer.gotoScene("floor2")
			end
		end
		stay_y:addEventListener("tap", tap_stayState)
		stay_n:addEventListener("tap", tap_stayState)

		local function decreaseTime()
			dialog_text.alpha = 0
			if itemList ~= nil then
				for i = 1, #itemList do
					inventory_red[i].alpha = 0
					itemIntro_text[i].alpha = 0
				end
			end

			text.text = "[시간이 감소하였습니다. 계속 머무르시겠습니까?]   네 / 아니오"
			dialog.alpha = 1
			text.alpha = 1

			dialogButton.alpha = 0
			backButton.alpha = 0

			flag = 1
			if itemList ~= nil then
				for i = 1, #itemList do
					item[i]:removeEventListener("tap", itemClick)
				end
			end
		end
		decreaseTime()

		time = display.newText(5, display.contentWidth*0.23, display.contentHeight*0.1)
		time.size = 20
		time:setFillColor(1)

		local function fiveMinute_counter ( event )
			time.text = time.text - 1

	 		if time.text == '0' then
	 			dialog_text.alpha = 0
	 			for i = 1, #itemList do
	 				inventory_red[i].alpha = 0
					itemIntro_text[i].alpha = 0
				end

	 			text.text = "[시간이 감소하였습니다.]"
	 			dialog.alpha = 1
	 			dialogButton.alpha = 1
	 			text.alpha = 1

				backButton.alpha = 1
	 			composer.setVariable("timeDecrease", "true")
	 		end
	 	end
	 	timeAttack = timer.performWithDelay(60000, fiveMinute_counter, 5)

		sceneGroup:insert(time)
		sceneGroup:insert(stay_y)
		sceneGroup:insert(stay_n)

		time:toBack()
		stay_y:toBack()
		stay_n:toBack()
	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
	elseif phase == "did" then
		-- Called when the scene is now off screen
	end
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene
