local composer = require( "composer" )
local scene = composer.newScene()

function scene:create( event )
	local sceneGroup = self.view
	local background = display.newImageRect("Image_K/3rd_hall_class (2).jpg", display.contentWidth, display.contentHeight)
 	background.x, background.y = display.contentWidth/2, display.contentHeight/2
 	
 	local right = display.newImage("Image_K/right.png")
 	right.x, right.y = display.contentWidth*0.87, display.contentHeight*0.5

	------ 화면전환 ------------------------------------------------------------
	local function tapRightEventListener( event )
 		print("오른쪽을 클릭했습니다")
 		composer.gotoScene('class4')
 	end 
 	right:addEventListener("tap", tapRightEventListener)
 	-------- 클릭후 멘트 ---------------------------------------------------------------

 	local classFive = display.newRect( display.contentWidth*0.73, display.contentHeight*0.6, 150, 400)
 	local classSix = display.newRect( display.contentWidth*0.61, display.contentHeight*0.6, 70, 300)
 	local classSixB = display.newRect( display.contentWidth*0.5, display.contentHeight*0.6, 40, 200)
	local classSeven = display.newRect( display.contentWidth*0.46, display.contentHeight*0.55, 30, 250)
	local classSevenB = display.newRect( display.contentWidth*0.4, display.contentHeight*0.55, 10, 200)
	local classEight = display.newRect( display.contentWidth*0.35, display.contentHeight*0.55, 10, 190)
	local classEightB = display.newRect( display.contentWidth*0.38, display.contentHeight*0.55, 10, 200)

	local Data = jsonParse("json/lock.json")

	local next  = display.newImage(Data[1].next, display.contentWidth* 0.86, display.contentHeight*0.95)
	local image = display.newImage(Data[1].image, display.contentWidth*0.4, display.contentHeight*0.85)
	local info = display.newText(Data[1].info, display.contentWidth*0.5, display.contentHeight*0.85, display.contentWidth*0.93, display.contentHeight*0.16)
	next:toBack()
	image:toBack()
	info:toBack()
	
	local function tapEventListener( event )
 		print("문을 클릭했습니다")
		if( Data ) then
			print( Data[1].next )
			print( Data[1].info )
			print( Data[1].back )
		end

		info:setFillColor(1)
		info.size = 30

		next:toFront()
		image:toFront()
		info:toFront()
 	end

 	local function tapNeEventListener( event )
 		print("다음")
		next:toBack()
		image:toBack()
		info:toBack()
 	end 
 	
 	classFive:addEventListener("tap", tapEventListener)
 	classSix:addEventListener("tap", tapEventListener)
 	classSixB:addEventListener("tap", tapEventListener)
 	classSeven:addEventListener("tap", tapEventListener)
 	classSevenB:addEventListener("tap", tapEventListener)
 	classEight:addEventListener("tap", tapEventListener)
 	classEightB:addEventListener("tap", tapEventListener)
 	next:addEventListener("tap", tapNeEventListener)
--------------------------------------------------------------------------------------------------------------------------------

	sceneGroup:insert(background)
 	sceneGroup:insert(right)
 	sceneGroup:insert(classFive)
 	sceneGroup:insert(classSix)
 	sceneGroup:insert(classSixB)
 	sceneGroup:insert(classSeven)
 	sceneGroup:insert(classSevenB)
 	sceneGroup:insert(classEight)
 	sceneGroup:insert(classEightB)

 	classFive:toBack()
 	classSix:toBack()
 	classSixB:toBack()
 	classSeven:toBack()
 	classSevenB:toBack()
 	classEight:toBack()
 	classEightB:toBack()
end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen
	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
	elseif phase == "did" then
		-- Called when the scene is now off screen
	end
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene
