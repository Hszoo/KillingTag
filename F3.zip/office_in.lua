-----------------------------------------------------------------------------------------
--
-- office_in.lua
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()

function scene:create( event )
	local sceneGroup = self.view
	local background = display.newImageRect("Image_K/3rd_office_in.jpg", display.contentWidth, display.contentHeight)
 	background.x, background.y = display.contentWidth/2, display.contentHeight/2

 	local left = display.newImage("Image_K/left.png")
 	left.x, left.y = display.contentWidth*0.025, display.contentHeight*0.5

	local lock = display.newRect( display.contentWidth*0.62, display.contentHeight*0.75, 40, 40 )
	--local back = display.newRect( display.contentWidth*0.89, display.contentHeight*0.4, 20, 150 )
	------ 화면전환 ------------------------------------------------------------
	local function tapLockEventListener( event )
  		print("자물쇠를 클릭했습니다")
 		composer.gotoScene('office_desk')
 	end 
 	lock:addEventListener("tap", tapLockEventListener)

 	local function tapLeftEventListener( event )
 		print("왼쪽을 클릭했습니다")
 		composer.gotoScene('office')
 	end 
 	left:addEventListener("tap", tapLeftEventListener)

 	-------- 클릭후 멘트 ---------------------------------------------------------------
	local Data = jsonParse("json/officeMent.json")

	local next  = display.newImage(Data[2].next, display.contentWidth* 0.86, display.contentHeight*0.95)
	local image = display.newImage(Data[2].image, display.contentWidth*0.4, display.contentHeight*0.85)
	local info = display.newText(Data[2].info, display.contentWidth*0.5, display.contentHeight*0.85, display.contentWidth*0.93, display.contentHeight*0.16)
	info:setFillColor(1)
	info.size = 30

 	local function tapNeEventListener( event )
		print("다음")
	 	next:toBack()
		image:toBack()
		info:toBack()
	end 
 	
 	next:addEventListener("tap", tapNeEventListener)
--------------------------------------------------------------------------------------------------------------------------------

	sceneGroup:insert(background)
 	sceneGroup:insert(lock)
 	sceneGroup:insert(left)
 	sceneGroup:insert(next)
 	sceneGroup:insert(image)
 	sceneGroup:insert(info)

  	lock:toBack()
end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen
	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
	elseif phase == "did" then
		-- Called when the scene is now off screen
	end
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene
