-----------------------------------------------------------------------------------------
--
-- studio.lua
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()
local background
local index = 1
local wire_flag = 0
local mike_flag = 0
local button_flag = 0
local wire_outline = {}
local leftButton, rightButton, backButton
local text, dialog_text
local item_name, item, inventory, inventory_red, itemIntro_text
local itemList = {}
local content = display.newGroup()
local Data = jsonParse("json/studio_background.json")
local ItemList = jsonParse("json/ItemList.json")
local function itemClick( event )
	if itemList ~= nil then
		for i = 1, #itemList do
			if inventory_red[i].alpha == 1 then
				inventory_red[i].alpha = 0
			end
		end
		for i = 1, #itemList do
			if event.target.y + 30 > inventory_red[i].y and event.target.y - 30 < inventory_red[i].y then
				text.alpha = 0
				dialog_text.alpha = 0
				inventory_red[i].alpha = 1
				itemIntro_text[i].alpha = 1
				dialog.alpha = 1
 				dialogButton.alpha = 1
 			else
				itemIntro_text[i].alpha = 0
			end
		end
	end
end

local function item_get()
	inventory = {}
	inventory_red = {}
	item_name = {}
	item = {}
	itemIntro_text = {}
	if itemList ~= nil then
		for i = 1, #itemList do
			inventory[i] = display.newImage(content, "image/inventory.png")
			inventory[i].x, inventory[i].y = display.contentWidth*0.947, display.contentHeight*0.09 + (i - 1)*130

			inventory_red[i] = display.newImage(content, "image/inventory_red.png")
			inventory_red[i].x, inventory_red[i].y = display.contentWidth*0.947, display.contentHeight*0.09 + (i - 1)*130
			inventory_red[i].alpha = 0

			item_name[i] = ItemList[itemList[i]].name

			item[i] = display.newImage(content, ItemList[itemList[i]].image)
			item[i].x, item[i].y = display.contentWidth*0.947, display.contentHeight*0.09 + (i - 1)*130

			itemIntro_text[i] = display.newText(0, display.contentWidth*0.5, display.contentHeight*0.88)
			itemIntro_text[i].size = 25
			itemIntro_text[i]:setFillColor(1)
			itemIntro_text[i].text = ItemList[itemList[i]].intro
			itemIntro_text[i].alpha = 0
		end
	end

	if itemList ~= nil then
		for i = 1, #itemList do
			item[i]:addEventListener("touch", itemClick)
		end
	end
end

function scene:create( event )
	local sceneGroup = self.view

	background = display.newImageRect("image/studio1.jpg", display.contentWidth, display.contentHeight)
	background.x, background.y = display.contentWidth/2, display.contentHeight/2

	function touchItemList( event )
		if( event.phase == "began" ) then
			display.getCurrentStage():setFocus( event.target )
			event.target.isFocus = true
			event.target.yStart = event.target.y
	
		elseif( event.phase == "moved" ) then
			if( event.target.isFocus ) then
				event.target.y = event.target.yStart + event.yDelta
			end

		elseif( event.phase == "ended" or event.phase == "cancelled") then
			display.getCurrentStage():setFocus(nil)
			event.target.isFocus = false
		end
	end
	content:addEventListener("touch", touchItemList)

	itemList = composer.getVariable("keyItem")
	item_get()

	local mike_index = 0
	if itemList ~= nil then
		for i = 1, #itemList do
			if item_name[i] == "고장난 마이크" then
			  	mike_index = i
			end
		end
	end
	local studio_mike = display.newRect(display.contentCenterX + 30, display.contentCenterY + 100, 100, 120)
	local function dragMike( event )
 		if( event.phase == "began" ) then
 			display.getCurrentStage():setFocus( event.target )
 			event.target.isFocus = true
 			event.target.initX = event.target.x
 			event.target.initY = event.target.y

 			content:removeEventListener("touch", touchItemList)
 		elseif( event.phase == "moved" ) then
 			if ( event.target.isFocus and mike_flag == 0 ) then
 				event.target.x = event.xStart + event.xDelta - event.target.parent.x
 				event.target.y = event.yStart + event.yDelta - event.target.parent.y
 			end
 		elseif ( event.phase == "ended" or event.phase == "cancelled") then 
 			if ( event.target.isFocus ) then
	 			display.getCurrentStage():setFocus( nil )
	 			event.target.isFocus = false
	 			if event.target.x > studio_mike.x - 50 and event.target.x < studio_mike.x + 50
	 				and event.target.y > studio_mike.y - 50 and event.target.y < studio_mike.y + 50 and index == 1 then
	 			 	index = 6
	 			 	background.fill = {
	 					type = "image",
	 					filename = Data[index].image
	 				}
	 				item[mike_index].x = event.target.x
	 				item[mike_index].y = event.target.y
	 				mike_flag = 1
	 				for i = 1, #itemList do
						itemIntro_text[i].alpha = 0
					end
	 				text.text = "[고장난 마이크로 변경되었습니다. 이제 방송이 나오지 않습니다.]"
	 				text.alpha = 1
	 				dialog.alpha = 1
	 				dialogButton.alpha = 1
	 				dialog_text.alpha = 0

	 				item[mike_index].alpha = 0
				else
	 				event.target.x = event.target.initX
	 				event.target.y = event.target.initY
	 			end
	 		else
	 			display.getCurrentStage():setFocus( nil )
 				event.target.isFocus = false
 			end
 			content:addEventListener("touch", touchItemList)
 		end
 	end
 	if item ~= nil then
		if mike_index ~= nil then
			item[mike_index]:addEventListener("touch", dragMike)
		end
	end

	local wire = display.newRect(display.contentCenterX - 190, display.contentCenterY + 135, 40, 100)
	local function tapWire( event )
		backButton.alpha = 1
		leftButton.alpha = 0
		rightButton.alpha = 0

		if wire_flag == 0 then
			for i = 1, #itemList do
				itemIntro_text[i].alpha = 0
			end
			text.alpha = 0
			itemIntro_text.alpha = 0
			if itemList ~= nil then
				for i = 1, #itemList do
					if item_name[i] == "가위" then
						dialog_text.text = "일단 모든 경우의 수를 제거해야 해... 미친 살인마한테서 살아남으려면.\n저기 있는 선... 가위로 잘라버리자."
						dialog_text.alpha = 1
						dialog.alpha = 1
						dialogButton.alpha = 1
					end
				end
			end

			index = 3
		elseif wire_flag == 1 then
			index = 4
		end

	 	background.fill = {
	 		type = "image",
	 		filename = Data[index].image
	 	}
	end
	wire:addEventListener("tap", tapWire)

	local wire_outline_group = display.newGroup()
	wire_outline[1] = display.newRect(wire_outline_group, display.contentCenterX - 370, display.contentCenterY + 110, 70, 100)
	wire_outline[1]:rotate(110)
	wire_outline[2] = display.newRect(wire_outline_group, display.contentCenterX - 300, display.contentCenterY + 170, 70, 100)
	wire_outline[2]:rotate(150)
	wire_outline[3] = display.newRect(wire_outline_group, display.contentCenterX - 247, display.contentCenterY + 250, 70, 100)
	wire_outline[3]:rotate(140)
	wire_outline[4] = display.newRect(wire_outline_group, display.contentCenterX - 160, display.contentCenterY + 275, 70, 100)
	wire_outline[4]:rotate(80)
	wire_outline[5] = display.newRect(wire_outline_group, display.contentCenterX - 65, display.contentCenterY + 250, 70, 100)
	wire_outline[5]:rotate(70)
	wire_outline[6] = display.newRect(wire_outline_group, display.contentCenterX + 30, display.contentCenterY + 220, 70, 100)
	wire_outline[6]:rotate(80)
	wire_outline[7] = display.newRect(wire_outline_group, display.contentCenterX + 125, display.contentCenterY + 235, 70, 100)
	wire_outline[7]:rotate(100)
	wire_outline[8] = display.newRect(wire_outline_group, display.contentCenterX + 220, display.contentCenterY + 260, 70, 100)
	wire_outline[8]:rotate(90)
	wire_outline[9] = display.newRect(wire_outline_group, display.contentCenterX + 315, display.contentCenterY + 240, 70, 100)
	wire_outline[9]:rotate(70)
	wire_outline[10] = display.newRect(wire_outline_group, display.contentCenterX + 390, display.contentCenterY + 180, 70, 100)
	wire_outline[10]:rotate(30)
	wire_outline[11] = display.newRect(wire_outline_group, display.contentCenterX + 420, display.contentCenterY + 90, 70, 100)
	wire_outline[11]:rotate(10)
	wire_outline[12] = display.newRect(wire_outline_group, display.contentCenterX + 430, display.contentCenterY - 10, 70, 100)
	wire_outline[13] = display.newRect(wire_outline_group, display.contentCenterX + 430, display.contentCenterY - 90, 70, 70)

	
 	local controller = display.newRect(display.contentCenterX + 330, display.contentCenterY + 38, 110, 60)
	local function tapController( event )
		leftButton.alpha = 0
		rightButton.alpha = 0
		backButton.alpha = 1

		background.fill = {
			type = "image",
			filename = Data[5].image
		}
		index = 5
		control_button.alpha = 1

		if button_flag == 0 then
			text.alpha = 0
			for i = 1, #itemList do
				itemIntro_text[i].alpha = 0
			end
			dialog_text.text = "볼륨.. 이것만 위로 올라가 있네...?"
			dialog.alpha = 1
			dialogButton.alpha = 1
			dialog_text.alpha = 1
		end
	end
	controller:addEventListener("tap", tapController)

	control_button = display.newImage("image/control_button.png")
	control_button.x, control_button.y = display.contentWidth*0.765, display.contentHeight*0.23
	control_button.alpha = 0

	local function dragButton( event )
 		if( event.phase == "began" ) then
 			display.getCurrentStage():setFocus( event.target )
 			event.target.isFocus = true
 			event.target.initY = event.target.y
 		elseif( event.phase == "moved" ) then
 			if ( event.target.isFocus ) then
 				if event.yStart + event.yDelta > event.target.initY and event.yStart + event.yDelta < event.target.initY + 110 and button_flag == 0 then
 					event.target.y = event.yStart + event.yDelta - event.target.parent.y
 				end
 			end
 		elseif ( event.phase == "ended" or event.phase == "cancelled") then
 			if ( event.target.isFocus ) then
	 			display.getCurrentStage():setFocus( nil )
	 			event.target.isFocus = false
	 			if event.target.y > event.target.initY + 100 and event.target.y < event.target.initY + 110 then
	 				control_button.y = event.target.y
	 				dialog_text.alpha = 0
					for i = 1, #itemList do
						itemIntro_text[i].alpha = 0
					end
	 				button_flag = 1
	 				text.text = "[볼륨이 내려갔습니다.]"
	 				text.alpha = 1
	 				dialog.alpha = 1
	 				dialogButton.alpha = 1
	 			else
	 				event.target.y = event.target.initY
	 			end
	 		else
	 			display.getCurrentStage():setFocus( nil )
 				event.target.isFocus = false
 			end
 		end
 	end
 	control_button:addEventListener("touch", dragButton)

	local setting = display.newImage("image/setting.png")
	setting.x, setting.y = display.contentWidth*0.04, display.contentHeight*0.07

	local function tapSetting( event )
		for i = 1, #itemList do
			itemIntro_text[i].alpha = 0
		end
		dialog.alpha = 0
		dialogButton.alpha = 0
		dialog_text.alpha = 0
		text.alpha = 0
		composer.showOverlay("setting")
	end
	setting:addEventListener("tap", tapSetting)

	leftButton = display.newImage("image/left.png")
	leftButton.x, leftButton.y = display.contentWidth*0.04, display.contentHeight*0.5

	rightButton = display.newImage("image/right.png")
	rightButton.x, rightButton.y = display.contentWidth*0.86, display.contentHeight*0.5

	local function tapLeftButton( event )
		if index == 1 or index == 6 then
			index = 2
			backButton.alpha = 0
			item[mike_index].alpha = 0
		end

		background.fill = {
			type = "image",
			filename = Data[index].image
		}
	end
	local function tapRightButton( event )
		if index == 2 then
			if mike_flag == 1 then
				index = 6
				item[mike_index].alpha = 1
			else
				index = 1
			end
			backButton.alpha = 1
		end
		background.fill = {
			type = "image",
			filename = Data[index].image
		}
	end
	leftButton:addEventListener("tap", tapLeftButton)
	rightButton:addEventListener("tap", tapRightButton)

	backButton = display.newImage("image/back.png")
	backButton.x, backButton.y = display.contentWidth*0.5, display.contentHeight*0.94

	local function tapBackButton( event )
		dialog.alpha = 0
		dialogButton.alpha = 0
		dialog_text.alpha = 0
		text.alpha = 0
		for i = 1, #itemList do
			itemIntro_text[i].alpha = 0
		end

		if index == 3 or index == 4 then
			index = 2
			backButton.alpha = 0
		elseif index == 5 then
			index = 2
			control_button.alpha = 0
			backButton.alpha = 0
		elseif index == 1 or index == 6 then
			if itemList ~= nil then
				for i = 1, #itemList do
					itemIntro_text[i].alpha = 0
					inventory_red[i].alpha = 0
				end
			end
			composer.gotoScene("floor2")
		end

		background.fill = {
			type = "image",
			filename = Data[index].image
		}

		leftButton.alpha = 1
		rightButton.alpha = 1
	end
	backButton:addEventListener("tap", tapBackButton)

	dialog = display.newImage("image/dialog.png")
	dialog.x , dialog.y = display.contentWidth*0.5, display.contentHeight*0.9
	dialog.alpha = 0

	dialogButton = display.newImage("image/dialog_next.png")
	dialogButton.x , dialogButton.y = display.contentWidth*0.86, display.contentHeight*0.95
	dialog.alpha = 0

	local function tapDialogButton( event )
		dialog.alpha = 0
		dialogButton.alpha = 0
		text.alpha = 0
		dialog_text.alpha = 0
		if itemList ~= nil then
			for i = 1, #itemList do
				itemIntro_text[i].alpha = 0
			end
		end
	end
	dialogButton:addEventListener("tap", tapDialogButton)

	local inventoryList = display.newImage("image/inventory_list.png")
	inventoryList.x, inventoryList.y = display.contentWidth*0.95, display.contentHeight*0.5

	text = display.newText(0, display.contentWidth*0.5, display.contentHeight*0.88)
	text.size = 25
	text:setFillColor(1)
	text.alpha = 0

	dialog_text = display.newText(0, display.contentWidth*0.5, display.contentHeight*0.88)
	dialog_text.size = 25
	dialog_text:setFillColor(1)
	dialog_text.alpha = 0

	if itemList ~= nil then
		for i = 1, #itemList do
			if item_name[i] == "고장난 마이크" then
			  	dialog_text.text = "혹시 모르니까 음악실에서 주운 거랑 바꿔야겠다. 혹시 모르니까... 그치..."
				dialog.alpha = 1
				dialogButton.alpha = 1
				dialog_text.alpha = 1
			end
		end
	end

	sceneGroup:insert(background)
	sceneGroup:insert(studio_mike)
	sceneGroup:insert(wire)
	sceneGroup:insert(wire_outline_group)
	sceneGroup:insert(controller)
	sceneGroup:insert(control_button)
	sceneGroup:insert(setting)
	sceneGroup:insert(leftButton)
	sceneGroup:insert(rightButton)
	sceneGroup:insert(backButton)
	sceneGroup:insert(dialog)
	sceneGroup:insert(dialogButton)
	sceneGroup:insert(inventoryList)
	sceneGroup:insert(content)

	wire:toBack()
	wire_outline_group:toBack()
	controller:toBack()
	studio_mike:toBack()
end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen

		itemList = composer.getVariable("keyItem")
		item_get()

		local function dragScissors( event )		
 		if( event.phase == "began" ) then -- 드래그를 시작할 때   
 			display.getCurrentStage():setFocus( event.target )
 			event.target.isFocus = true -- isFocus 플래그(상호배제를 위한 플래그)를 세운다.
 			event.target.initX = event.target.x
 			event.target.initY = event.target.y

 			text.alpha = 0
	 		dialog_text.alpha = 0
	 		dialog.alpha = 0
	 		dialogButton.alpha = 0

	 		content:removeEventListener("touch", touchItemList)
 		elseif( event.phase == "moved" ) then
 			if ( event.target.isFocus ) then
 				-- 드래그 중일 때
 				event.target.x = event.xStart + event.xDelta - event.target.parent.x
 				event.target.y = event.yStart + event.yDelta - event.target.parent.y
 			end
 		elseif ( event.phase == "ended" or event.phase == "cancelled") then -- 드래그가 끝났을 때
 			if ( event.target.isFocus ) then -- isFocus 플래그가 세워져 있을 때
	 			display.getCurrentStage():setFocus( nil )
	 			event.target.isFocus = false -- 바로 isFocus 플래그를 내린다. (드래그가 끝났을 때, 단 한번만 돌아가게 하기 위해)
	 			-- 드래그 끝났을 때
	 			for i = 1, 13 do
	 				if event.target.x > wire_outline[i].x - 50 and event.target.x < wire_outline[i].x + 50
	 					and event.target.y > wire_outline[i].y - 50 and event.target.y < wire_outline[i].y + 50 and index == 3 then
	 			 		background.fill = {
							type = "image",
							filename = Data[4].image
						}
						wire_flag = 1 --자르기 성공
						text.text = "[방송 배선을 잘랐습니다.]"
	 					text.alpha = 1
	 					dialog.alpha = 1
	 					dialogButton.alpha = 1
					end
				end
	 			event.target.x = event.target.initX
	 			event.target.y = event.target.initY
	 		else
	 			display.getCurrentStage():setFocus( nil )
 				event.target.isFocus = false
 			end
 			content:addEventListener("touch", touchItemList)
 		end
 	end
	if itemList ~= nil then
		for i = 1, #itemList do
			if item_name[i] == "가위" then
			  	item[i]:addEventListener("touch", dragScissors)
			end
		end
	end

	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
		if mike_flag == 1 and button_flag == 1 then
			composer.setVariable("studio_flag", "false")
		else
			composer.setVariable("studio_flag", "true")
		end

		composer.setVariable("keyItem_studio", itemList)
	elseif phase == "did" then
		-- Called when the scene is now off screen
	end
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene
