-----------------------------------------------------------------------------------------
--
-- setting.lua
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()

function scene:create( event )
	local sceneGroup = self.view
	
 	local background = display.newImageRect("image/setting_set.png", display.contentWidth, display.contentHeight)
	background.x, background.y = display.contentWidth/2, display.contentHeight/2

	local exit = display.newImage("image/exit.png")
	exit.x, exit.y = display.contentWidth*0.85, display.contentHeight*0.08

	local function tapExit( event )
		composer.hideOverlay("setting")
	end
	exit:addEventListener("tap", tapExit)

	local b_off = display.newImage("image/off.png")
	b_off.x, b_off.y = display.contentWidth*0.55, display.contentHeight*0.395
	local b_on = display.newImage("image/on.png")
	b_on.x, b_on.y = display.contentWidth*0.55, display.contentHeight*0.395
	b_on.alpha = 0

	local function tapBButton( event )
		if b_off.alpha == 1 then
			b_off.alpha = 0
			b_on.alpha = 1
		else
			b_on.alpha = 1
			b_off.alpha = 0
		end
	end
	b_off:addEventListener("tap", tapBButton)
	b_on:addEventListener("tap", tapBButton)

	local e_off = display.newImage("image/off.png")
	e_off.x, e_off.y = display.contentWidth*0.55, display.contentHeight*0.495
	local e_on = display.newImage("image/on.png")
	e_on.x, e_on.y = display.contentWidth*0.55, display.contentHeight*0.495
	e_on.alpha = 0

	local function tapEButton( event )
		if e_off.alpha == 1 then
			e_off.alpha = 0
			e_on.alpha = 1
		else
			e_on.alpha = 1
			e_off.alpha = 0
		end
	end
	e_off:addEventListener("tap", tapEButton)
	e_on:addEventListener("tap", tapEButton)

	local home = display.newImage("image/home1.png")
	home.x, home.y = display.contentWidth*0.5, display.contentHeight*0.63

	local function tapHome( event )
		composer.hideOverlay("setting")
		composer.showOverlay("toHome")
	end
	home:addEventListener("tap", tapHome)

	-- 모두 sceneGroup에 넣었는지 점검
	sceneGroup:insert(background)
	sceneGroup:insert(exit)
	sceneGroup:insert(b_off)
	sceneGroup:insert(b_on)
	sceneGroup:insert(e_off)
	sceneGroup:insert(e_on)
	sceneGroup:insert(home)
end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen

	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
	elseif phase == "did" then
		-- Called when the scene is now off screen

	end
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene